# CarePoint Clinic Appointment System

A PHP, MySQL, HTML, CSS, and JavaScript clinic appointment project with Admin, Doctor, and Patient roles. The interface uses a navy and teal medical theme with responsive layouts and subtle card depth.

## Run with XAMPP

1. Copy this folder into `C:\xampp8\htdocs\clinic_appointment` (or your XAMPP `htdocs` folder).
2. Start Apache and MySQL in XAMPP.
3. Open phpMyAdmin, create/import the project database using `database/schema.sql`.
4. Optionally import `database/demo_seed.sql` to add three fictional departments.
5. If your MySQL connection differs from the XAMPP defaults, copy `.env.example` to `.env` and set `DB_HOST`, `DB_NAME`, `DB_USER`, and `DB_PASSWORD`. The app reads these environment variables; configure them in Apache/PHP for your setup.
6. Create the first administrator at `/clinic_appointment/admin/setup_admin.php`.
7. Sign in as admin, add doctors and weekly schedules. Register a patient and book a future open slot.

The local defaults are database `clinic_db`, user `root`, and a blank password. Never use those defaults on a public server.

## Demo workflow

Admin creates a department/doctor and schedule → patient registers and books an open slot → admin approves or rejects with a reason → patient sees the update → admin marks the visit complete and records a note → patient views medical history.

The active appointment unique key prevents two pending/approved bookings for one doctor and time. Cancelled and rejected appointments remain in history while reopening their time slots.

## Database privacy

`database/schema.sql` contains table definitions only. `database/demo_seed.sql` contains fictional department names only. Do not commit database exports from a clinic with real patient details, medical notes, emails, phone numbers, or account password hashes.

## Images and libraries

Some presentation images and Bootstrap styling load from external CDNs and need an internet connection. The PHP application and database run locally through XAMPP.

## Note

The schema is a fresh-install schema based on the app's current SQL usage. It has not yet been imported into a separate empty database for verification. Keep your existing `clinic_db` unchanged; use a separate test database before trying a fresh import.
