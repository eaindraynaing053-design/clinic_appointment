<?php

require_once "config/database.php";

echo "Database Connected Successfully!";

?>