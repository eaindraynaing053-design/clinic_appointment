<?php
require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../config/database.php';

requireRole('patient');

$patientId = (int)$_SESSION['user_id'];
$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if (!verifyCsrfToken()) {
        $message = 'Session expired. Please refresh and try again.';
    } else {

        $appointmentId = (int)($_POST['appointment_id'] ?? 0);

        $stmt = $pdo->prepare("
            SELECT *
            FROM appointments
            WHERE id = ? AND patient_id = ?
        ");
        $stmt->execute([$appointmentId, $patientId]);
        $appointment = $stmt->fetch();

        if (!$appointment) {
            $message = 'Appointment not found.';
        } elseif (!in_array($appointment['status'], ['pending', 'approved'], true)) {
            $message = 'This appointment cannot be cancelled.';
        } else {

            $appointmentDateTime = strtotime(
                $appointment['appointment_date'] . ' ' . $appointment['appointment_time']
            );

            if ($appointmentDateTime === false || $appointmentDateTime < time() + 86400) {
                $message = 'Appointments can only be cancelled at least 24 hours in advance.';
            } else {

                $update = $pdo->prepare("
                    UPDATE appointments
                    SET status = 'cancelled'
                    WHERE id = ? AND patient_id = ?
                ");

                $update->execute([$appointmentId, $patientId]);

                $notification = $pdo->prepare("
                    INSERT INTO notifications (user_id, message)
                    VALUES (?, ?)
                ");

                $notification->execute([
                    $patientId,
                    'Your appointment has been cancelled successfully.'
                ]);

                setFlash('success', 'Your appointment has been cancelled.');
                redirect('patient/my_appointments.php');
            }
        }
    }
}

$stmt = $pdo->prepare("
    SELECT a.*, d.doctor_name, 'Medical Specialist' AS specialization,
           dep.department_name
    FROM appointments a
    INNER JOIN doctors d ON a.doctor_id = d.id
    INNER JOIN departments dep ON d.department_id = dep.id
    WHERE a.patient_id = ?
    ORDER BY a.appointment_date DESC, a.appointment_time DESC
");

$stmt->execute([$patientId]);
$appointments = $stmt->fetchAll();

$flash = getFlash();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>My Appointments | CarePoint Clinic</title>
<link rel="stylesheet" href="<?= BASE_URL ?>assets/css/style.css">

<style>
.appointment-page{max-width:1150px;margin:45px auto;padding:0 20px}
.appointment-heading{margin-bottom:25px}
.appointment-heading h1{color:#12385c;font-size:30px}
.appointment-heading p{color:#7b8b9b;margin-top:8px}
.appointment-panel{background:white;padding:25px;border-radius:15px;border:1px solid #e6edf4;box-shadow:0 7px 25px rgba(20,50,80,.06);overflow-x:auto}
.appointment-table{width:100%;border-collapse:collapse;min-width:850px}
.appointment-table th,.appointment-table td{padding:15px 12px;text-align:left;border-bottom:1px solid #edf1f5}
.appointment-table th{color:#75869a;font-size:13px}
.status-label{padding:6px 11px;border-radius:20px;font-size:12px;font-weight:bold;text-transform:capitalize}
.status-pending{background:#fff3d7;color:#916200}
.status-approved{background:#ddf6e7;color:#167342}
.status-rejected{background:#ffe4e1;color:#b33c35}
.status-cancelled{background:#edf0f3;color:#586879}
.status-completed{background:#dceeff;color:#1767a1}
.cancel-btn{border:0;background:#fff0ef;color:#b33c35;padding:9px 13px;border-radius:7px;cursor:pointer;font-weight:bold}
.cancel-btn:hover{background:#ffdcd9}
.alert{padding:14px;border-radius:9px;margin-bottom:18px}
.alert-error{background:#fff0ef;color:#b33c35}
.alert-success{background:#e3f7e9;color:#176d3e}
.empty-state{text-align:center;padding:45px;color:#75869a}
.book-link{display:inline-block;margin-top:15px;padding:12px 20px;background:#147caf;color:white;text-decoration:none;border-radius:8px}
.reason{font-size:12px;color:#b33c35;margin-top:7px}
</style>
    <link rel="stylesheet" href="<?= BASE_URL ?>assets/css/premium.css">
</head>

<body>

<nav class="navbar">
    <a class="logo" href="<?= BASE_URL ?>index.php">CarePoint Clinic</a>
    <div>
        <a href="<?= BASE_URL ?>patient/dashboard.php">Dashboard</a>
        <a href="<?= BASE_URL ?>patient/doctors.php">Find Doctors</a>
        <a href="<?= BASE_URL ?>patient/profile.php">Profile</a>
        <a href="<?= BASE_URL ?>auth/logout.php">Logout</a>
    </div>
</nav>

<main class="appointment-page">

    <div class="appointment-heading">
        <h1>My Appointments</h1>
        <p>View and manage your medical appointments.</p>
    </div>

    <?php if ($flash): ?>
        <div class="alert alert-<?= e($flash['type']) ?>">
            <?= e($flash['message']) ?>
        </div>
    <?php endif; ?>

    <?php if ($message): ?>
        <div class="alert alert-error"><?= e($message) ?></div>
    <?php endif; ?>

    <section class="appointment-panel">

        <?php if ($appointments): ?>

            <table class="appointment-table">

                <thead>
                    <tr>
                        <th>Doctor</th>
                        <th>Department</th>
                        <th>Date</th>
                        <th>Time</th>
                        <th>Status</th>
                        <th>Action</th>
                    </tr>
                </thead>

                <tbody>

                    <?php foreach ($appointments as $appointment): ?>

                        <tr>

                            <td>
                                Dr. <?= e($appointment['doctor_name']) ?>
                            </td>

                            <td><?= e($appointment['department_name']) ?></td>

                            <td><?= date('d M Y', strtotime($appointment['appointment_date'])) ?></td>

                            <td><?= date('h:i A', strtotime($appointment['appointment_time'])) ?></td>

                            <td>
                                <span class="status-label status-<?= e($appointment['status']) ?>">
                                    <?= e($appointment['status']) ?>
                                </span>

                                <?php if ($appointment['status'] === 'rejected' && $appointment['rejection_reason']): ?>
                                    <div class="reason">
                                        Reason: <?= e($appointment['rejection_reason']) ?>
                                    </div>
                                <?php endif; ?>
                            </td>

                            <td>

                                <?php
                                $appointmentTimestamp = strtotime(
                                    $appointment['appointment_date'] . ' ' . $appointment['appointment_time']
                                );

                                $canCancel =
                                    in_array($appointment['status'], ['pending', 'approved'], true)
                                    && $appointmentTimestamp >= time() + 86400;
                                ?>

                                <?php if ($canCancel): ?>

                                    <form method="POST"
                                          onsubmit="return confirm('Are you sure you want to cancel this appointment?');">

                                        <input type="hidden" name="csrf_token" value="<?= e(csrfToken()) ?>">

                                        <input type="hidden"
                                               name="appointment_id"
                                               value="<?= (int)$appointment['id'] ?>">

                                        <button type="submit" class="cancel-btn">
                                            Cancel
                                        </button>

                                    </form>

                                <?php else: ?>

                                    <span style="color:#8a99a8;font-size:13px;">—</span>

                                <?php endif; ?>

                            </td>

                        </tr>

                    <?php endforeach; ?>

                </tbody>

            </table>

        <?php else: ?>

            <div class="empty-state">
                <h2>No Appointments Yet</h2>
                <p>You haven't booked any appointments.</p>
                <a class="book-link" href="<?= BASE_URL ?>patient/doctors.php">
                    Find a Doctor
                </a>
            </div>

        <?php endif; ?>

    </section>

</main>

    <script defer src="<?= BASE_URL ?>assets/js/script.js"></script>
</body>
</html>
