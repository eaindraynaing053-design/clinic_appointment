<?php
require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../config/database.php';

requireRole('patient');

$patientId = (int)$_SESSION['user_id'];
$message = '';
$messageType = 'error';

$ageColumn = $pdo->query("SHOW COLUMNS FROM users LIKE 'age'")->fetch();
$hasAge = (bool)$ageColumn;
$profileFields = 'id, name AS full_name, email, phone, blood_type, created_at';
if ($hasAge) {
    $profileFields .= ', age';
}
$stmt = $pdo->prepare("
    SELECT $profileFields
    FROM users
    WHERE id = ? AND role = 'patient'
");
$stmt->execute([$patientId]);
$patient = $stmt->fetch();

if (!$patient) {
    exit('Patient account not found.');
}

$fullName = $patient['full_name'];
$email = $patient['email'];
$phone = $patient['phone'] ?? '';
$ageInput = (string)($patient['age'] ?? '');
$bloodType = $patient['blood_type'] ?? '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if (!verifyCsrfToken()) {
        $message = 'Session expired. Please refresh and try again.';
    } else {

        $fullName = trim($_POST['full_name'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $phone = trim($_POST['phone'] ?? '');
        $ageInput = trim($_POST['age'] ?? '');
        $bloodType = trim($_POST['blood_type'] ?? '');

        $validBloodTypes = ['', 'A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];

        if ($fullName === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $message = 'Please enter a valid name and email address.';
        } elseif ($hasAge && $ageInput !== '' && (!ctype_digit($ageInput) || (int)$ageInput < 1 || (int)$ageInput > 120)) {
            $message = 'Please enter a valid age.';
        } elseif (!in_array($bloodType, $validBloodTypes, true)) {
            $message = 'Please select a valid blood type.';
        } else {

            $check = $pdo->prepare("
                SELECT id FROM users
                WHERE email = ? AND id != ?
            ");
            $check->execute([$email, $patientId]);

            if ($check->fetch()) {
                $message = 'This email address is already registered.';
            } else {

                $update = $pdo->prepare("
                    UPDATE users
                    SET name = ?, email = ?, phone = ?, blood_type = ?
                    WHERE id = ? AND role = 'patient'
                ");

                $update->execute([
                    $fullName,
                    $email,
                    $phone ?: null,
                    $bloodType ?: null,
                    $patientId
                ]);

                if ($hasAge) {
                    $ageUpdate = $pdo->prepare("UPDATE users SET age = ? WHERE id = ? AND role = 'patient'");
                    $ageUpdate->execute([$ageInput !== '' ? (int)$ageInput : null, $patientId]);
                }

                $_SESSION['full_name'] = $fullName;
                $_SESSION['email'] = $email;

                setFlash('success', 'Your profile has been updated successfully.');
                redirect('patient/profile.php');
            }
        }
    }

    $patient['full_name'] = $fullName;
    $patient['email'] = $email;
    $patient['phone'] = $phone;
    if ($hasAge) {
        $patient['age'] = $ageInput;
    }
    $patient['blood_type'] = $bloodType;
}

$flash = getFlash();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>My Profile | CarePoint Clinic</title>
<link rel="stylesheet" href="<?= BASE_URL ?>assets/css/style.css">

<style>
.profile-container{max-width:800px;margin:45px auto;padding:0 20px}
.profile-card{background:white;padding:35px;border-radius:17px;border:1px solid #e7edf4;box-shadow:0 8px 30px rgba(20,50,80,.07)}
.profile-card h1{color:#12385c;margin-bottom:8px}
.profile-subtitle{color:#8290a0;margin-bottom:28px}
.profile-grid{display:grid;grid-template-columns:1fr 1fr;gap:20px}
.profile-field label{display:block;color:#34516c;font-weight:bold;margin-bottom:8px}
.profile-field input,.profile-field select{width:100%;padding:14px;border:1px solid #dce5ee;border-radius:9px;font-size:15px}
.profile-field input:focus,.profile-field select:focus{outline:2px solid #9dd6ee;border-color:#147caf}
.profile-field.full{grid-column:1/-1}
.profile-submit{margin-top:25px;width:100%;padding:15px;background:#147caf;color:white;border:0;border-radius:9px;font-weight:bold;font-size:16px;cursor:pointer;box-shadow:0 5px 0 #0c547d}
.profile-submit:hover{transform:translateY(2px);box-shadow:0 3px 0 #0c547d}
.profile-alert{padding:14px;border-radius:9px;margin-bottom:20px}
.profile-error{background:#fff0ef;color:#b33c35}
.profile-success{background:#e3f7e9;color:#176d3e}
.profile-date{margin-top:22px;color:#8493a3;font-size:13px}
@media(max-width:600px){.profile-grid{grid-template-columns:1fr}.profile-card{padding:23px}}
</style>
    <link rel="stylesheet" href="<?= BASE_URL ?>assets/css/premium.css">
</head>

<body>

<nav class="navbar">
    <a class="logo" href="<?= BASE_URL ?>index.php">CarePoint Clinic</a>
    <div>
        <a href="<?= BASE_URL ?>patient/dashboard.php">Dashboard</a>
        <a href="<?= BASE_URL ?>patient/my_appointments.php">Appointments</a>
        <a href="<?= BASE_URL ?>auth/logout.php">Logout</a>
    </div>
</nav>

<main class="profile-container">

    <div class="profile-card">

        <h1>My Profile</h1>
        <p class="profile-subtitle">Keep your personal information up to date.</p>

        <?php if ($message): ?>
            <div class="profile-alert profile-error"><?= e($message) ?></div>
        <?php endif; ?>

        <?php if ($flash): ?>
            <div class="profile-alert profile-success"><?= e($flash['message']) ?></div>
        <?php endif; ?>

        <form method="POST">

            <input type="hidden" name="csrf_token" value="<?= e(csrfToken()) ?>">

            <div class="profile-grid">

                <div class="profile-field full">
                    <label>Full Name</label>
                    <input type="text" name="full_name"
                           value="<?= e($patient['full_name']) ?>" required maxlength="100">
                </div>

                <div class="profile-field full">
                    <label>Email Address</label>
                    <input type="email" name="email"
                           value="<?= e($patient['email']) ?>" required maxlength="100">
                </div>

                <div class="profile-field">
                    <label>Phone Number</label>
                    <input type="tel" name="phone"
                           value="<?= e($patient['phone']) ?>" maxlength="20">
                </div>

                <?php if ($hasAge): ?>
                <div class="profile-field">
                    <label>Age</label>
                    <input type="number" name="age"
                           value="<?= e($patient['age']) ?>" min="1" max="120">
                </div>
                <?php endif; ?>

                <div class="profile-field full">
                    <label>Blood Type</label>

                    <select name="blood_type">
                        <option value="">Select Blood Type</option>

                        <?php foreach (['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'] as $type): ?>

                            <option value="<?= $type ?>"
                                <?= ($patient['blood_type'] ?? '') === $type ? 'selected' : '' ?>>
                                <?= $type ?>
                            </option>

                        <?php endforeach; ?>

                    </select>
                </div>

            </div>

            <button type="submit" class="profile-submit">
                Save Profile Changes
            </button>

        </form>

        <p class="profile-date">
            Registered on: <?= date('d M Y', strtotime($patient['created_at'])) ?>
        </p>

    </div>

</main>

    <script defer src="<?= BASE_URL ?>assets/js/script.js"></script>
</body>
</html>
