<?php
require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../config/database.php';

requireRole('patient');

$departmentId = (int)($_GET['department'] ?? 0);

$sql = "
    SELECT d.*, d.fee AS consultation_fee, 'Medical Specialist' AS specialization, dep.department_name
    FROM doctors d
    INNER JOIN departments dep ON d.department_id = dep.id
";

$params = [];

if ($departmentId > 0) {
    $sql .= " WHERE d.department_id = ?";
    $params[] = $departmentId;
}

$sql .= " ORDER BY d.doctor_name ASC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$doctors = $stmt->fetchAll();

$departments = $pdo->query("
    SELECT * FROM departments ORDER BY department_name
")->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Find a Doctor | CarePoint Clinic</title>
<link rel="stylesheet" href="<?= BASE_URL ?>assets/css/style.css">

<style>
.patient-page{max-width:1200px;margin:45px auto;padding:0 22px}
.page-heading{text-align:center;margin-bottom:30px}
.page-heading h1{color:#12385c;font-size:32px}
.page-heading p{color:#728399;margin-top:10px}
.filter-bar{display:flex;justify-content:center;margin-bottom:30px}
.filter-bar select{padding:13px;border:1px solid #dce5ee;border-radius:9px;min-width:250px}
.doctor-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:25px}
.doctor-card{background:#fff;border:1px solid #e7edf4;border-radius:16px;overflow:hidden;box-shadow:0 8px 25px rgba(20,50,80,.07);transition:.3s}
.doctor-card:hover{transform:translateY(-6px);box-shadow:0 15px 30px rgba(20,50,80,.12)}
.doctor-photo{height:210px;background:linear-gradient(135deg,#dceef8,#edf5fb);display:flex;align-items:center;justify-content:center;overflow:hidden}
.doctor-photo img{width:100%;height:100%;object-fit:cover}
.doctor-placeholder{font-size:65px;color:#3989b5}
.doctor-info{padding:23px}
.doctor-info h2{color:#12385c;font-size:21px;margin-bottom:8px}
.doctor-info p{color:#718196;margin:8px 0}
.doctor-fee{color:#1678ad;font-size:19px;font-weight:bold;margin:17px 0}
.book-btn{display:block;text-align:center;background:#147caf;color:white;text-decoration:none;padding:13px;border-radius:9px;font-weight:bold;box-shadow:0 5px 0 #0c547d;transition:.2s}
.book-btn:hover{transform:translateY(2px);box-shadow:0 3px 0 #0c547d}
.empty-state{text-align:center;padding:50px;color:#718196;background:white;border-radius:15px}
@media(max-width:900px){.doctor-grid{grid-template-columns:repeat(2,1fr)}}
@media(max-width:600px){.doctor-grid{grid-template-columns:1fr}}
</style>
    <link rel="stylesheet" href="<?= BASE_URL ?>assets/css/premium.css">
</head>

<body>

<nav class="navbar">
    <a class="logo" href="<?= BASE_URL ?>index.php">CarePoint Clinic</a>
    <div>
        <a href="<?= BASE_URL ?>patient/dashboard.php">Dashboard</a>
        <a href="<?= BASE_URL ?>patient/my_appointments.php">Appointments</a>
        <a href="<?= BASE_URL ?>auth/logout.php">Logout</a>
    </div>
</nav>

<main class="patient-page">

    <div class="page-heading">
        <h1>Find Your Doctor</h1>
        <p>Choose a qualified doctor and book your consultation.</p>
    </div>

    <form method="GET" class="filter-bar">
        <select name="department" onchange="this.form.submit()">
            <option value="0">All Departments</option>

            <?php foreach ($departments as $department): ?>
                <option value="<?= (int)$department['id'] ?>"
                    <?= $departmentId === (int)$department['id'] ? 'selected' : '' ?>>
                    <?= e($department['department_name']) ?>
                </option>
            <?php endforeach; ?>
        </select>
    </form>

    <?php if ($doctors): ?>

        <div class="doctor-grid">

            <?php foreach ($doctors as $doctor): ?>

                <article class="doctor-card">

                    <div class="doctor-photo">
                        <?php if (!empty($doctor['photo'])): ?>
                            <img src="<?= e($doctor['photo']) ?>" alt="Doctor photo">
                        <?php else: ?>
                            <span class="doctor-placeholder">✚</span>
                        <?php endif; ?>
                    </div>

                    <div class="doctor-info">

                        <h2><?= e($doctor['doctor_name']) ?></h2>

                        <p>
                            <?= e($doctor['department_name']) ?>
                        </p>

                        <p>
                            <?= e($doctor['specialization'] ?: 'Medical Specialist') ?>
                        </p>

                        <div class="doctor-fee">
                            <?= number_format((float)$doctor['consultation_fee'], 2) ?> MMK
                        </div>

                        <a class="book-btn"
                           href="<?= BASE_URL ?>patient/book_appointments.php?doctor_id=<?= (int)$doctor['id'] ?>">
                            Book Appointment
                        </a>

                    </div>
                </article>

            <?php endforeach; ?>

        </div>

    <?php else: ?>

        <div class="empty-state">
            <h2>No doctors found</h2>
            <p>Please select another department.</p>
        </div>

    <?php endif; ?>

</main>

    <script defer src="<?= BASE_URL ?>assets/js/script.js"></script>
</body>
</html>
