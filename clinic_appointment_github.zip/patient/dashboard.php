
<?php
require_once "../includes/auth_check.php";
require_once "../config/database.php";

requireRole("patient");

$patientId = (int) $_SESSION["user_id"];
$patientName = $_SESSION["full_name"] ?? "Patient";

// Appointment statistics
$stmt = $pdo->prepare("
    SELECT
        COUNT(*) AS total,
        SUM(status = 'pending') AS pending,
        SUM(status = 'approved') AS approved,
        SUM(status = 'completed') AS completed
    FROM appointments
    WHERE patient_id = ?
");
$stmt->execute([$patientId]);
$stats = $stmt->fetch();

// Upcoming appointments
$stmt = $pdo->prepare("
    SELECT
        a.id,
        a.appointment_date,
        a.appointment_time,
        a.status,
        d.doctor_name,
        dep.department_name
    FROM appointments a
    JOIN doctors d ON a.doctor_id = d.id
    LEFT JOIN departments dep ON d.department_id = dep.id
    WHERE a.patient_id = ?
      AND a.appointment_date >= CURDATE()
      AND a.status IN ('pending', 'approved')
    ORDER BY a.appointment_date, a.appointment_time
    LIMIT 5
");
$stmt->execute([$patientId]);
$upcoming = $stmt->fetchAll();

// Unread notifications
$stmt = $pdo->prepare("
    SELECT COUNT(*)
    FROM notifications
    WHERE user_id = ? AND is_read = 0
");
$stmt->execute([$patientId]);
$unreadNotifications = (int) $stmt->fetchColumn();

function patientStatusClass($status) {
    return match ($status) {
        "approved" => "approved",
        "pending" => "pending",
        "completed" => "completed",
        "rejected", "cancelled" => "rejected",
        default => "pending"
    };
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Patient Dashboard | MediCare Clinic</title>
    <link rel="stylesheet" href="../assets/css/style.css">

    <style>
        .patient-page {
            max-width: 1200px;
            margin: 35px auto;
            padding: 0 22px;
            color: #18344d;
        }

        .patient-topbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 15px;
            margin-bottom: 30px;
        }

        .patient-topbar h1 {
            font-size: 29px;
            margin-bottom: 7px;
        }

        .patient-topbar p {
            color: #718096;
        }

        .patient-btn {
            display: inline-block;
            text-decoration: none;
            background: #087f8c;
            color: white;
            padding: 12px 20px;
            border-radius: 10px;
            font-weight: 600;
            transition: .25s;
        }

        .patient-btn:hover {
            background: #075e68;
            transform: translateY(-3px);
        }

        .patient-stats {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 18px;
            margin-bottom: 30px;
        }

        .patient-stat {
            background: white;
            padding: 24px;
            border-radius: 16px;
            box-shadow: 0 8px 25px rgba(20, 50, 75, .07);
            border: 1px solid #e9f0f5;
        }

        .patient-stat span {
            color: #718096;
            font-size: 14px;
        }

        .patient-stat h2 {
            font-size: 30px;
            margin-top: 10px;
            color: #087f8c;
        }

        .patient-panel {
            background: white;
            padding: 25px;
            border-radius: 16px;
            box-shadow: 0 8px 25px rgba(20, 50, 75, .06);
            border: 1px solid #e9f0f5;
            margin-bottom: 25px;
        }

        .patient-panel h2 {
            margin-bottom: 20px;
            font-size: 20px;
        }

        .patient-table {
            width: 100%;
            border-collapse: collapse;
        }

        .patient-table th,
        .patient-table td {
            padding: 15px 12px;
            text-align: left;
            border-bottom: 1px solid #edf2f7;
            font-size: 14px;
        }

        .patient-table th {
            color: #718096;
            background: #f7fafc;
        }

        .patient-badge {
            display: inline-block;
            padding: 6px 11px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 700;
            text-transform: capitalize;
        }

        .approved {
            color: #087443;
            background: #dcfce7;
        }

        .pending {
            color: #996500;
            background: #fef3c7;
        }

        .completed {
            color: #1755a0;
            background: #dbeafe;
        }

        .rejected {
            color: #b42318;
            background: #fee2e2;
        }

        .patient-quicklinks {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 15px;
        }

        .patient-quicklinks a {
            padding: 20px;
            text-decoration: none;
            color: #18344d;
            background: #f5fafc;
            border: 1px solid #e3edf2;
            border-radius: 13px;
            font-weight: 600;
            transition: .25s;
        }

        .patient-quicklinks a:hover {
            background: #e5f5f5;
            transform: translateY(-3px);
        }

        .patient-empty {
            color: #718096;
            padding: 20px 0;
        }

        @media(max-width: 800px) {
            .patient-stats {
                grid-template-columns: repeat(2, 1fr);
            }

            .patient-quicklinks {
                grid-template-columns: 1fr;
            }

            .patient-table {
                min-width: 650px;
            }

            .patient-table-wrap {
                overflow-x: auto;
            }
        }

        @media(max-width: 450px) {
            .patient-stats {
                grid-template-columns: 1fr;
            }
        }
    </style>
    <link rel="stylesheet" href="<?= BASE_URL ?>assets/css/premium.css">
</head>

<body>

<div class="patient-page">

    <div class="patient-topbar">
        <div>
            <h1>Welcome, <?= e($patientName) ?> 👋</h1>
            <p>Here's your personal healthcare overview.</p>
        </div>

        <a href="doctors.php" class="patient-btn">
            + Book Appointment
        </a>
    </div>

    <div class="patient-stats">

        <div class="patient-stat">
            <span>Total Appointments</span>
            <h2><?= (int)($stats["total"] ?? 0) ?></h2>
        </div>

        <div class="patient-stat">
            <span>Pending</span>
            <h2><?= (int)($stats["pending"] ?? 0) ?></h2>
        </div>

        <div class="patient-stat">
            <span>Approved</span>
            <h2><?= (int)($stats["approved"] ?? 0) ?></h2>
        </div>

        <div class="patient-stat">
            <span>Completed Visits</span>
            <h2><?= (int)($stats["completed"] ?? 0) ?></h2>
        </div>

    </div>

    <div class="patient-panel">

        <h2>Upcoming Appointments</h2>

        <?php if ($upcoming): ?>

            <div class="patient-table-wrap">
                <table class="patient-table">
                    <thead>
                        <tr>
                            <th>Doctor</th>
                            <th>Department</th>
                            <th>Date</th>
                            <th>Time</th>
                            <th>Status</th>
                        </tr>
                    </thead>

                    <tbody>
                    <?php foreach ($upcoming as $appointment): ?>
                        <tr>
                            <td><?= e($appointment["doctor_name"]) ?></td>
                            <td><?= e($appointment["department_name"] ?? "General") ?></td>
                            <td><?= e($appointment["appointment_date"]) ?></td>
                            <td><?= e(date("h:i A", strtotime($appointment["appointment_time"]))) ?></td>
                            <td>
                                <span class="patient-badge <?= patientStatusClass($appointment["status"]) ?>">
                                    <?= e($appointment["status"]) ?>
                                </span>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

        <?php else: ?>

            <p class="patient-empty">
                You don't have any upcoming appointments.
                Book an appointment to get started.
            </p>

        <?php endif; ?>

    </div>

    <div class="patient-panel">

        <h2>Quick Access</h2>

        <div class="patient-quicklinks">
            <a href="doctors.php">🩺 Browse Doctors</a>
            <a href="my_appointments.php">📅 My Appointments</a>
            <a href="profile.php">👤 My Profile</a>
            <a href="medical_history.php">📋 Medical History</a>
            <a href="notifications.php">
                🔔 Notifications
                <?php if ($unreadNotifications > 0): ?>
                    (<?= $unreadNotifications ?> new)
                <?php endif; ?>
            </a>
            <a href="../auth/logout.php">↪ Log Out</a>
        </div>

    </div>

</div>

    <script defer src="<?= BASE_URL ?>assets/js/script.js"></script>
</body>
</html>
