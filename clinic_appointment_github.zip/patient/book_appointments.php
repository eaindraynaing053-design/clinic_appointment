<?php
require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../config/database.php';

requireRole('patient');

$patientId = (int)$_SESSION['user_id'];
$doctorId = (int)($_GET['doctor_id'] ?? $_POST['doctor_id'] ?? 0);

$message = '';
$messageType = 'error';
$selectedDate = $_POST['appointment_date'] ?? $_GET['date'] ?? date('Y-m-d');

$stmt = $pdo->prepare("
    SELECT d.*, d.fee AS consultation_fee, 'Medical Specialist' AS specialization, dep.department_name
    FROM doctors d
    INNER JOIN departments dep ON d.department_id = dep.id
    WHERE d.id = ?
");
$stmt->execute([$doctorId]);
$doctor = $stmt->fetch();

if (!$doctor) {
    http_response_code(404);
    exit('Doctor not found.');
}

function getAvailableSlots(PDO $pdo, int $doctorId, string $date): array
{
    return availableAppointmentSlots($pdo, $doctorId, $date);
}

$availableSlots = [];

if ($selectedDate !== '') {
    $availableSlots = getAvailableSlots($pdo, $doctorId, $selectedDate);
}

// Process booking
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if (!verifyCsrfToken()) {
        $message = 'Your session expired. Please refresh the page and try again.';
    } else {

        $appointmentDate = $_POST['appointment_date'] ?? '';
        $appointmentTime = $_POST['appointment_time'] ?? '';

        $slots = getAvailableSlots($pdo, $doctorId, $appointmentDate);

        if (!in_array($appointmentTime, $slots, true)) {
            $message = 'This appointment slot is no longer available. Please choose another time.';
        } else {

            try {
                $pdo->beginTransaction();
                $stmt = $pdo->prepare("
                    INSERT INTO appointments
                    (patient_id, doctor_id, appointment_date, appointment_time, status)
                    VALUES (?, ?, ?, ?, 'pending')
                ");

                $stmt->execute([
                    $patientId,
                    $doctorId,
                    $appointmentDate,
                    $appointmentTime
                ]);

                $appointmentId = (int)$pdo->lastInsertId();

                $notification = $pdo->prepare("
                    INSERT INTO notifications (user_id, message)
                    VALUES (?, ?)
                ");

                $notification->execute([
                    $patientId,
                    "Your appointment request with Dr. {$doctor['doctor_name']} has been submitted."
                ]);

                $pdo->commit();

                setFlash('success', 'Appointment request submitted successfully.');
                redirect('patient/my_appointments.php');

            } catch (PDOException $e) {
                if ($pdo->inTransaction()) {
                    $pdo->rollBack();
                }
                if ($e->getCode() === '23000') {
                    $message = 'Sorry, this appointment time has just been booked. Please select another slot.';
                } else {
                    $message = 'Unable to save your appointment. Please try again.';
                }
            }
        }

        $selectedDate = $appointmentDate;
        $availableSlots = getAvailableSlots($pdo, $doctorId, $selectedDate);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Book Appointment | CarePoint Clinic</title>
<link rel="stylesheet" href="<?= BASE_URL ?>assets/css/style.css">

<style>
.booking-container{max-width:850px;margin:50px auto;padding:0 20px}
.booking-card{background:#fff;padding:35px;border-radius:18px;box-shadow:0 10px 35px rgba(20,50,80,.09);border:1px solid #e7edf4}
.booking-card h1{color:#12385c;margin-bottom:10px}
.booking-subtitle{color:#7b8b9b;margin-bottom:25px}
.doctor-summary{background:#edf6fb;padding:20px;border-radius:12px;margin-bottom:25px}
.doctor-summary strong{display:block;color:#12385c;font-size:19px;margin-bottom:5px}
.booking-form label{display:block;font-weight:700;color:#34516c;margin-bottom:8px}
.booking-form input,.booking-form select{width:100%;padding:14px;border:1px solid #dce5ee;border-radius:9px;margin-bottom:20px;font-size:15px}
.slot-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin:12px 0 25px}
.slot-option input{display:none}
.slot-option span{display:block;padding:13px 8px;text-align:center;border:1px solid #d5e2ed;border-radius:9px;cursor:pointer;color:#24506f;font-weight:700}
.slot-option input:checked+span{background:#147caf;color:white;border-color:#147caf;box-shadow:0 4px 10px rgba(20,124,175,.2)}
.booking-submit{width:100%;padding:15px;border:0;border-radius:9px;background:#147caf;color:white;font-weight:700;font-size:16px;cursor:pointer;box-shadow:0 5px 0 #0c547d}
.booking-submit:hover{transform:translateY(2px);box-shadow:0 3px 0 #0c547d}
.alert-error{padding:14px;background:#fff0ef;color:#b33c35;border-radius:9px;margin-bottom:20px}
.no-slots{padding:18px;background:#fff7e7;color:#8a650d;border-radius:9px;margin-bottom:20px}
.back-link{display:inline-block;margin-bottom:20px;color:#1678ad;text-decoration:none}
@media(max-width:550px){.slot-grid{grid-template-columns:repeat(2,1fr)}.booking-card{padding:22px}}
</style>
    <link rel="stylesheet" href="<?= BASE_URL ?>assets/css/premium.css">
</head>

<body>

<nav class="navbar">
    <a class="logo" href="<?= BASE_URL ?>index.php">CarePoint Clinic</a>
    <div>
        <a href="<?= BASE_URL ?>patient/dashboard.php">Dashboard</a>
        <a href="<?= BASE_URL ?>patient/my_appointments.php">My Appointments</a>
        <a href="<?= BASE_URL ?>auth/logout.php">Logout</a>
    </div>
</nav>

<main class="booking-container">

    <a class="back-link" href="<?= BASE_URL ?>patient/doctors.php">← Back to Doctors</a>

    <div class="booking-card">

        <h1>Book Your Appointment</h1>
        <p class="booking-subtitle">Choose a convenient date and available consultation time.</p>

        <div class="doctor-summary">
            <strong>Dr. <?= e($doctor['doctor_name']) ?></strong>
            <?= e($doctor['department_name']) ?>
            <p><?= e($doctor['specialization'] ?: 'Medical Specialist') ?></p>
            <p>Consultation Fee: <?= number_format((float)$doctor['consultation_fee'], 2) ?> MMK</p>
        </div>

        <?php if ($message): ?>
            <div class="alert-error"><?= e($message) ?></div>
        <?php endif; ?>

        <form method="GET" class="booking-form">
            <input type="hidden" name="doctor_id" value="<?= $doctorId ?>">

            <label for="date">Select Appointment Date</label>

            <input
                type="date"
                id="date"
                name="date"
                min="<?= date('Y-m-d') ?>"
                value="<?= e($selectedDate) ?>"
                required
            >

            <button class="booking-submit" type="submit">
                Check Available Times
            </button>
        </form>

        <hr style="border:0;border-top:1px solid #e8eef4;margin:25px 0;">

        <form method="POST" class="booking-form">

            <input type="hidden" name="csrf_token" value="<?= e(csrfToken()) ?>">
            <input type="hidden" name="doctor_id" value="<?= $doctorId ?>">
            <input type="hidden" name="appointment_date" value="<?= e($selectedDate) ?>">

            <label>Available Appointment Times</label>

            <?php if ($availableSlots): ?>

                <div class="slot-grid">

                    <?php foreach ($availableSlots as $slot): ?>

                        <label class="slot-option">
                            <input
                                type="radio"
                                name="appointment_time"
                                value="<?= e($slot) ?>"
                                required
                            >
                            <span><?= date('h:i A', strtotime($slot)) ?></span>
                        </label>

                    <?php endforeach; ?>

                </div>

                <button type="submit" class="booking-submit">
                    Confirm Appointment
                </button>

            <?php else: ?>

                <div class="no-slots">
                    No available appointment times for this date.
                    Please choose another date.
                </div>

            <?php endif; ?>

        </form>

    </div>

</main>

    <script defer src="<?= BASE_URL ?>assets/js/script.js"></script>
</body>
</html>
