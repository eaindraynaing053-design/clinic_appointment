<?php
require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../config/database.php';

requireRole('patient');

$patientId = (int)$_SESSION['user_id'];
$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if (!verifyCsrfToken()) {
        $message = 'Session expired. Please refresh and try again.';
    } else {

        $action = $_POST['action'] ?? '';

        if ($action === 'read_all') {

            $stmt = $pdo->prepare("
                UPDATE notifications
                SET is_read = 1
                WHERE user_id = ?
            ");

            $stmt->execute([$patientId]);

            $message = 'All notifications have been marked as read.';

        } elseif ($action === 'read_one') {

            $notificationId = (int)($_POST['notification_id'] ?? 0);

            $stmt = $pdo->prepare("
                UPDATE notifications
                SET is_read = 1
                WHERE id = ? AND user_id = ?
            ");

            $stmt->execute([$notificationId, $patientId]);

            $message = 'Notification marked as read.';
        }
    }
}

$stmt = $pdo->prepare("
    SELECT *
    FROM notifications
    WHERE user_id = ?
    ORDER BY created_at DESC
");

$stmt->execute([$patientId]);
$notifications = $stmt->fetchAll();

$unreadCount = 0;

foreach ($notifications as $notification) {
    if (!(int)$notification['is_read']) {
        $unreadCount++;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Notifications | CarePoint Clinic</title>
<link rel="stylesheet" href="<?= BASE_URL ?>assets/css/style.css">

<style>
.notification-container{max-width:900px;margin:45px auto;padding:0 20px}
.notification-heading{display:flex;justify-content:space-between;align-items:center;gap:15px;margin-bottom:25px}
.notification-heading h1{color:#12385c;font-size:30px}
.notification-heading p{color:#8290a0;margin-top:7px}
.unread-count{background:#e6f4fc;color:#147caf;padding:9px 14px;border-radius:20px;font-weight:bold;font-size:13px}
.notification-panel{background:white;padding:25px;border-radius:15px;border:1px solid #e7edf4;box-shadow:0 7px 25px rgba(20,50,80,.06)}
.notification-item{display:flex;justify-content:space-between;align-items:center;gap:20px;padding:20px 10px;border-bottom:1px solid #edf1f5}
.notification-item:last-child{border-bottom:0}
.notification-item.unread{background:#f4faff;border-radius:9px}
.notification-message{color:#34516c;line-height:1.6}
.notification-date{font-size:12px;color:#8a99a8;margin-top:7px}
.read-btn{border:1px solid #cbdce9;background:white;color:#147caf;padding:9px 12px;border-radius:7px;cursor:pointer;white-space:nowrap}
.read-btn:hover{background:#eaf6fc}
.read-all-btn{background:#147caf;color:white;border:0;padding:12px 17px;border-radius:8px;font-weight:bold;cursor:pointer}
.notification-alert{background:#e3f7e9;color:#176d3e;padding:13px;border-radius:9px;margin-bottom:18px}
.empty-notifications{text-align:center;padding:45px;color:#8290a0}
@media(max-width:600px){.notification-heading{align-items:flex-start;flex-direction:column}.notification-item{align-items:flex-start;flex-direction:column}}
</style>
    <link rel="stylesheet" href="<?= BASE_URL ?>assets/css/premium.css">
</head>

<body>

<nav class="navbar">
    <a class="logo" href="<?= BASE_URL ?>index.php">CarePoint Clinic</a>
    <div>
        <a href="<?= BASE_URL ?>patient/dashboard.php">Dashboard</a>
        <a href="<?= BASE_URL ?>patient/my_appointments.php">Appointments</a>
        <a href="<?= BASE_URL ?>auth/logout.php">Logout</a>
    </div>
</nav>

<main class="notification-container">

    <div class="notification-heading">

        <div>
            <h1>Notifications</h1>
            <p>Stay updated about your appointments.</p>
        </div>

        <span class="unread-count">
            <?= $unreadCount ?> Unread
        </span>

    </div>

    <?php if ($message): ?>
        <div class="notification-alert"><?= e($message) ?></div>
    <?php endif; ?>

    <section class="notification-panel">

        <?php if ($unreadCount > 0): ?>

            <form method="POST" style="text-align:right;margin-bottom:15px;">
                <input type="hidden" name="csrf_token" value="<?= e(csrfToken()) ?>">
                <input type="hidden" name="action" value="read_all">

                <button class="read-all-btn" type="submit">
                    Mark All as Read
                </button>
            </form>

        <?php endif; ?>

        <?php if ($notifications): ?>

            <?php foreach ($notifications as $notification): ?>

                <div class="notification-item <?= !(int)$notification['is_read'] ? 'unread' : '' ?>">

                    <div>

                        <div class="notification-message">
                            <?= e($notification['message']) ?>
                        </div>

                        <div class="notification-date">
                            <?= date('d M Y, h:i A', strtotime($notification['created_at'])) ?>
                            <?= !(int)$notification['is_read'] ? ' • New' : ' • Read' ?>
                        </div>

                    </div>

                    <?php if (!(int)$notification['is_read']): ?>

                        <form method="POST">

                            <input type="hidden" name="csrf_token" value="<?= e(csrfToken()) ?>">
                            <input type="hidden" name="action" value="read_one">
                            <input type="hidden"
                                   name="notification_id"
                                   value="<?= (int)$notification['id'] ?>">

                            <button type="submit" class="read-btn">
                                Mark as Read
                            </button>

                        </form>

                    <?php endif; ?>

                </div>

            <?php endforeach; ?>

        <?php else: ?>

            <div class="empty-notifications">
                <h2>No Notifications</h2>
                <p>You don't have any notifications yet.</p>
            </div>

        <?php endif; ?>

    </section>

</main>

    <script defer src="<?= BASE_URL ?>assets/js/script.js"></script>
</body>
</html>