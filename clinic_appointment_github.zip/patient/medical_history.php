<?php
require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../config/database.php';

requireRole('patient');

$patientId = (int)$_SESSION['user_id'];

$stmt = $pdo->prepare("
    SELECT
        vn.id,
        vn.notes AS visit_note,
        vn.prescription,
        vn.created_at,
        d.doctor_name,
        dep.department_name,
        a.appointment_date,
        a.appointment_time
    FROM visit_notes vn
    INNER JOIN appointments a ON vn.appointment_id = a.id
    INNER JOIN doctors d ON vn.doctor_id = d.id
    INNER JOIN departments dep ON d.department_id = dep.id
    WHERE a.patient_id = ?
    ORDER BY vn.created_at DESC
");

$stmt->execute([$patientId]);
$medicalRecords = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Medical History | CarePoint Clinic</title>
<link rel="stylesheet" href="<?= BASE_URL ?>assets/css/style.css">

<style>
.history-container{max-width:950px;margin:45px auto;padding:0 20px}
.history-heading{margin-bottom:30px}
.history-heading h1{font-size:30px;color:#12385c}
.history-heading p{color:#8290a0;margin-top:8px}
.history-card{background:white;border:1px solid #e7edf4;border-radius:15px;padding:25px;margin-bottom:20px;box-shadow:0 6px 22px rgba(20,50,80,.06)}
.history-card h2{color:#12385c;font-size:20px;margin-bottom:8px}
.history-meta{color:#7b8b9b;font-size:14px;margin-bottom:20px}
.history-section{background:#f5f8fb;border-radius:10px;padding:18px;margin-top:12px}
.history-section h3{font-size:15px;color:#147caf;margin-bottom:9px}
.history-section p{color:#43586d;line-height:1.7;white-space:pre-wrap}
.empty-history{text-align:center;background:white;padding:50px;border-radius:15px;color:#7b8b9b}
.history-icon{font-size:28px;margin-bottom:12px}
</style>
    <link rel="stylesheet" href="<?= BASE_URL ?>assets/css/premium.css">
</head>

<body>

<nav class="navbar">
    <a class="logo" href="<?= BASE_URL ?>index.php">CarePoint Clinic</a>
    <div>
        <a href="<?= BASE_URL ?>patient/dashboard.php">Dashboard</a>
        <a href="<?= BASE_URL ?>patient/profile.php">Profile</a>
        <a href="<?= BASE_URL ?>auth/logout.php">Logout</a>
    </div>
</nav>

<main class="history-container">

    <div class="history-heading">
        <h1>My Medical History</h1>
        <p>Review your previous consultations and medical records.</p>
    </div>

    <?php if ($medicalRecords): ?>

        <?php foreach ($medicalRecords as $record): ?>

            <article class="history-card">

                <h2>Dr. <?= e($record['doctor_name']) ?></h2>

                <div class="history-meta">
                    <?= e($record['department_name']) ?>
                    &nbsp; | &nbsp;
                    <?= date('d M Y', strtotime($record['appointment_date'])) ?>
                    &nbsp; | &nbsp;
                    <?= date('h:i A', strtotime($record['appointment_time'])) ?>
                </div>

                <div class="history-section">
                    <h3>Doctor's Visit Notes</h3>

                    <p><?= e($record['visit_note'] ?: 'No visit notes recorded.') ?></p>
                </div>

                <div class="history-section">
                    <h3>Prescription</h3>

                    <p><?= e($record['prescription'] ?: 'No prescription recorded.') ?></p>
                </div>

            </article>

        <?php endforeach; ?>

    <?php else: ?>

        <div class="empty-history">
            <div class="history-icon">✚</div>
            <h2>No Medical Records Yet</h2>
            <p>Your medical history will appear after your doctor records a consultation.</p>
        </div>

    <?php endif; ?>

</main>

    <script defer src="<?= BASE_URL ?>assets/js/script.js"></script>
</body>
</html>
