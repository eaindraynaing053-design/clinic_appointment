
<?php

$scriptDir = trim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '/')), '/');
$pathParts = $scriptDir === '' || $scriptDir === '.' ? [] : explode('/', $scriptDir);
if ($pathParts && in_array(end($pathParts), ['admin', 'auth', 'patient', 'doctor'], true)) {
    array_pop($pathParts);
}
define('BASE_URL', '/' . implode('/', $pathParts) . (count($pathParts) ? '/' : ''));

// Escape output safely
function e($value): string {
    return htmlspecialchars(
        (string)($value ?? ''),
        ENT_QUOTES,
        'UTF-8'
    );
}

// Redirect to a project page
function redirect(string $path): void {
    header('Location: ' . BASE_URL . ltrim($path, '/'));
    exit;
}

// Login status
function isLoggedIn(): bool {
    return isset($_SESSION['user_id']);
}

// Current user role
function currentRole(): string {
    return $_SESSION['role'] ?? '';
}

// Protect pages from unauthenticated visitors
function requireLogin(): void {
    if (!isLoggedIn()) {
        redirect('auth/login.php');
    }
}

// Protect pages by role
function requireRole(string $role): void {
    requireLogin();

    if (currentRole() !== $role) {
        http_response_code(403);
        exit('Access denied. You are not authorized.');
    }
}

// Dashboard destination
function dashboardPath(string $role): string {
    switch ($role) {
        case 'admin':
            return 'admin/dashboard.php';

        case 'doctor':
            return 'doctor/dashboard.php';

        case 'patient':
            return 'patient/dashboard.php';

        default:
            return 'index.php';
    }
}

// Flash messages
function setFlash(string $type, string $message): void {
    $_SESSION['flash'] = [
        'type' => $type,
        'message' => $message
    ];
}

function getFlash(): ?array {
    if (!isset($_SESSION['flash'])) {
        return null;
    }

    $flash = $_SESSION['flash'];
    unset($_SESSION['flash']);

    return $flash;
}

// CSRF protection
function csrfToken(): string {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }

    return $_SESSION['csrf_token'];
}

function verifyCsrfToken(): bool {
    return isset($_POST['csrf_token'], $_SESSION['csrf_token'])
        && hash_equals(
            $_SESSION['csrf_token'],
            $_POST['csrf_token']
        );
}

// Create notification
function notifyUser(
    PDO $pdo,
    int $userId,
    string $message
): void {
    $stmt = $pdo->prepare(
        "INSERT INTO notifications (user_id, message)
         VALUES (?, ?)"
    );

    $stmt->execute([$userId, $message]);
}

/** Return future schedule slots that are not on leave or already reserved. */
function availableAppointmentSlots(PDO $pdo, int $doctorId, string $date, ?int $excludeAppointmentId = null): array {
    $day = DateTimeImmutable::createFromFormat('!Y-m-d', $date);
    if (!$day || $day->format('Y-m-d') !== $date || $date < date('Y-m-d')) {
        return [];
    }

    $off = $pdo->prepare('SELECT 1 FROM days_off WHERE doctor_id = ? AND ? BETWEEN start_date AND end_date LIMIT 1');
    $off->execute([$doctorId, $date]);
    if ($off->fetchColumn()) {
        return [];
    }

    $schedule = $pdo->prepare('SELECT start_time, end_time, slot_minutes AS slot_duration FROM doctor_schedules WHERE doctor_id = ? AND day_of_week = ? ORDER BY start_time');
    $schedule->execute([$doctorId, (int)$day->format('N')]);
    $reservedQuery = "SELECT appointment_time FROM appointments WHERE doctor_id = ? AND appointment_date = ? AND status IN ('pending', 'approved')";
    if ($excludeAppointmentId !== null) {
        $reservedQuery .= ' AND id <> ?';
    }
    $reserved = $pdo->prepare($reservedQuery);
    $reservedParams = [$doctorId, $date];
    if ($excludeAppointmentId !== null) {
        $reservedParams[] = $excludeAppointmentId;
    }
    $reserved->execute($reservedParams);
    $booked = array_column($reserved->fetchAll(), 'appointment_time');

    $slots = [];
    foreach ($schedule->fetchAll() as $window) {
        $start = new DateTimeImmutable($date . ' ' . $window['start_time']);
        $end = new DateTimeImmutable($date . ' ' . $window['end_time']);
        $duration = max(1, (int)$window['slot_duration']);
        $interval = new DateInterval('PT' . $duration . 'M');
        for ($slot = $start; $slot->add($interval) <= $end; $slot = $slot->add($interval)) {
            $time = $slot->format('H:i:s');
            if (!in_array($time, $booked, true)
                && !($date === date('Y-m-d') && $slot <= new DateTimeImmutable())) {
                $slots[] = $time;
            }
        }
    }
    return array_values(array_unique($slots));
}
