
<?php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . "/functions.php";

// Check whether the user is logged in.
requireLogin();
