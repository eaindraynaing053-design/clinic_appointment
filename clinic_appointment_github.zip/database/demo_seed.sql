-- Fictional starter departments only. Safe to import for a classroom demo.
USE clinic_db;
INSERT IGNORE INTO departments (department_name, description) VALUES
('General Medicine', 'Primary care and general health consultations.'),
('Dental Care', 'Dental examinations and oral health services.'),
('Ophthalmology', 'Eye examinations and vision care.');
