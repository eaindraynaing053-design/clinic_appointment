-- Optional profile enhancement for the existing clinic_db schema.
-- The application works without this column, but patient age will only be
-- saved and displayed after this additive migration is applied once.
ALTER TABLE users ADD COLUMN age TINYINT UNSIGNED NULL AFTER phone;
