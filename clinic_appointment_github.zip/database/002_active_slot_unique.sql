-- Approved repair for the live clinic_db schema.
-- The previous unique_doctor_slot index reserved canceled/rejected times too.
-- This preserves all appointment rows while enforcing uniqueness only for
-- pending and approved appointments. Run once against clinic_db.
ALTER TABLE appointments
    DROP INDEX unique_doctor_slot,
    ADD COLUMN active_slot TINYINT
        GENERATED ALWAYS AS (
            CASE WHEN status IN ('pending', 'approved') THEN 1 ELSE NULL END
        ) PERSISTENT,
    ADD UNIQUE KEY unique_active_doctor_slot
        (doctor_id, appointment_date, appointment_time, active_slot);
