
<?php
require_once "../includes/auth_check.php";
require_once "../config/database.php";
requireRole("admin");

$search = trim($_GET["search"] ?? "");

$sql = "
    SELECT
        u.id,
        u.name AS full_name,
        u.email,
        u.phone,
        u.age,
        u.blood_type,
        u.created_at,
        COUNT(a.id) AS appointment_count
    FROM users u
    LEFT JOIN appointments a ON a.patient_id = u.id
    WHERE u.role = 'patient'
";

$params = [];

if ($search !== "") {
    $sql .= " AND (
        u.name LIKE ?
        OR u.email LIKE ?
        OR u.phone LIKE ?
    )";

    $term = "%" . $search . "%";
    $params = [$term, $term, $term];
}

$sql .= "
    GROUP BY
        u.id, u.name, u.email, u.phone,
        u.age, u.blood_type, u.created_at
    ORDER BY u.created_at DESC
";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$patients = $stmt->fetchAll();

$totalPatients = (int)$pdo->query(
    "SELECT COUNT(*) FROM users WHERE role = 'patient'"
)->fetchColumn();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Patient Management | Clinic Admin</title>

    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/admin.css">
    <link rel="stylesheet" href="../assets/css/premium.css">
</head>
<body class="admin-page">

<div class="admin-container">

    <div class="admin-heading">
        <div>
            <h1>Patient Management</h1>
            <p>View and search registered patient information.</p>
        </div>

        <a href="dashboard.php" class="admin-btn admin-btn-secondary">
            Back to Dashboard
        </a>
    </div>

    <nav class="admin-nav">
        <a href="dashboard.php">Dashboard</a>
        <a href="departments.php">Departments</a>
        <a href="doctors.php">Doctors</a>
        <a href="schedules.php">Schedules</a>
        <a href="days_off.php">Days Off</a>
        <a href="appointments.php">Appointments</a>
        <a href="patients.php">Patients</a>
        <a href="visit_notes.php">Visit Notes</a>
        <a href="../auth/logout.php">Logout</a>
    </nav>

    <section class="admin-stats">
        <div class="admin-stat">
            <h3>Total Registered Patients</h3>
            <p><?= $totalPatients ?></p>
        </div>

        <div class="admin-stat">
            <h3>Search Results</h3>
            <p><?= count($patients) ?></p>
        </div>
    </section>

    <section class="admin-card">
        <h2>Patient Directory</h2>

        <form method="GET" class="admin-form">
            <div class="admin-field">
                <label>Search Patient</label>
                <input
                    type="text"
                    name="search"
                    value="<?= htmlspecialchars($search) ?>"
                    placeholder="Search by name, email or phone"
                >
            </div>

            <div class="admin-actions">
                <button type="submit" class="admin-btn admin-btn-primary">
                    Search
                </button>

                <a href="patients.php" class="admin-btn admin-btn-secondary">
                    Clear
                </a>
            </div>
        </form>

        <div class="admin-table-wrap">
            <table class="admin-table">
                <thead>
                    <tr>
                        <th>No.</th>
                        <th>Patient Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Age</th>
                        <th>Blood Type</th>
                        <th>Appointments</th>
                        <th>Registered</th>
                    </tr>
                </thead>

                <tbody>
                <?php if (!$patients): ?>
                    <tr>
                        <td colspan="8">No patients found.</td>
                    </tr>
                <?php else: ?>

                    <?php foreach ($patients as $index => $patient): ?>
                        <tr>
                            <td><?= $index + 1 ?></td>

                            <td><?= htmlspecialchars($patient["full_name"]) ?></td>

                            <td><?= htmlspecialchars($patient["email"]) ?></td>

                            <td><?= htmlspecialchars($patient["phone"] ?? "—") ?></td>

                            <td><?= htmlspecialchars((string)($patient["age"] ?? "—")) ?></td>

                            <td><?= htmlspecialchars($patient["blood_type"] ?? "—") ?></td>

                            <td><?= (int)$patient["appointment_count"] ?></td>

                            <td>
                                <?= date("d M Y", strtotime($patient["created_at"])) ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>

                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </section>

</div>
    <script defer src="../assets/js/script.js"></script>
</body>
</html>
