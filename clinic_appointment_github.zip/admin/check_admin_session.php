
<?php
require_once "../includes/auth_check.php";

echo "<h2>Admin Session Diagnostic</h2>";

echo "<p><strong>User ID:</strong> "
    . htmlspecialchars((string)($_SESSION["user_id"] ?? "Missing"))
    . "</p>";

echo "<p><strong>Full Name:</strong> "
    . htmlspecialchars((string)($_SESSION["full_name"] ?? "Missing"))
    . "</p>";

echo "<p><strong>Session Role:</strong> "
    . htmlspecialchars((string)($_SESSION["role"] ?? "Missing"))
    . "</p>";

echo "<p><strong>currentRole():</strong> "
    . htmlspecialchars(currentRole())
    . "</p>";

if (currentRole() === "admin") {
    echo "<h3 style='color:green'>Admin session is correct!</h3>";
} else {
    echo "<h3 style='color:red'>Your current session is not Admin.</h3>";
}
?>
echo "<hr>";

requireRole("admin");

echo "<h2 style='color:green'>
Admin permission check PASSED!
</h2>";