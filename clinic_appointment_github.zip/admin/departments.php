
<?php
require_once "../includes/auth_check.php";
require_once "../config/database.php";

// Only administrators can access this page.
if (($_SESSION["role"] ?? "") !== "admin") {
    http_response_code(403);
    exit("Access denied. Please log in using an administrator account.");
}

$message = "";
$messageType = "success";
$editDepartment = null;

// Add or update department
if ($_SERVER["REQUEST_METHOD"] === "POST") {

    if (!verifyCsrfToken()) {
        $message = "Invalid security token. Please refresh the page.";
        $messageType = "error";

    } else {
        $action = $_POST["action"] ?? "";

        if ($action === "save") {
            $id = (int)($_POST["department_id"] ?? 0);
            $name = trim($_POST["department_name"] ?? "");
            $description = trim($_POST["description"] ?? "");

            if ($name === "") {
                $message = "Please enter a department name.";
                $messageType = "error";

            } else {
                try {
                    if ($id > 0) {
                        $stmt = $pdo->prepare(
                            "UPDATE departments
                             SET department_name = ?, description = ?
                             WHERE id = ?"
                        );

                        $stmt->execute([$name, $description, $id]);
                        $message = "Department updated successfully.";

                    } else {
                        $stmt = $pdo->prepare(
                            "INSERT INTO departments
                             (department_name, description)
                             VALUES (?, ?)"
                        );

                        $stmt->execute([$name, $description]);
                        $message = "Department added successfully.";
                    }

                } catch (PDOException $e) {
                    $message = "Unable to save department. The department name may already exist.";
                    $messageType = "error";
                }
            }
        }

        // Delete department
        if ($action === "delete") {
            $id = (int)($_POST["department_id"] ?? 0);

            try {
                $stmt = $pdo->prepare(
                    "DELETE FROM departments WHERE id = ?"
                );

                $stmt->execute([$id]);
                $message = "Department deleted successfully.";

            } catch (PDOException $e) {
                $message = "This department cannot be deleted because doctors may be assigned to it.";
                $messageType = "error";
            }
        }
    }
}

// Load department for editing
if (isset($_GET["edit"])) {
    $id = (int)$_GET["edit"];

    $stmt = $pdo->prepare(
        "SELECT * FROM departments WHERE id = ?"
    );

    $stmt->execute([$id]);
    $editDepartment = $stmt->fetch();
}

// Get all departments
$stmt = $pdo->query(
    "SELECT d.*,
        (SELECT COUNT(*) FROM doctors doc
         WHERE doc.department_id = d.id) AS doctor_count
     FROM departments d
     ORDER BY d.department_name ASC"
);

$departments = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Department Management | ClinicCare</title>

    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/admin.css">
    <link rel="stylesheet" href="../assets/css/premium.css">
</head>

<body class="admin-page">

<div class="admin-container">

    <header class="admin-heading">
        <div>
            <h1>Department Management</h1>
            <p>Manage the medical departments in your clinic.</p>
        </div>

        <a href="../auth/logout.php" class="admin-btn admin-btn-danger">
            Logout
        </a>
    </header>

    <nav class="admin-nav">
        <a href="dashboard.php">Dashboard</a>
        <a href="departments.php" class="active">Departments</a>
        <a href="doctors.php">Doctors</a>
        <a href="schedules.php">Schedules</a>
        <a href="days_off.php">Days Off</a>
        <a href="appointments.php">Appointments</a>
        <a href="patients.php">Patients</a>
        <a href="visit_notes.php">Visit Notes</a>
    </nav>

    <?php if ($message !== ""): ?>
        <div class="admin-alert <?= $messageType === "error" ? "error" : "success" ?>">
            <?= e($message) ?>
        </div>
    <?php endif; ?>

    <section class="admin-card">
        <h2>
            <?= $editDepartment ? "Edit Department" : "Add New Department" ?>
        </h2>

        <form method="POST" class="admin-form">

            <input type="hidden" name="csrf_token"
                   value="<?= e(csrfToken()) ?>">

            <input type="hidden" name="action" value="save">

            <input type="hidden" name="department_id"
                   value="<?= e($editDepartment["id"] ?? "") ?>">

            <div class="admin-field">
                <label>Department Name</label>
                <input
                    type="text"
                    name="department_name"
                    placeholder="Enter department name"
                    value="<?= e($editDepartment["department_name"] ?? "") ?>"
                    required
                >
            </div>

            <div class="admin-field">
                <label>Description</label>
                <textarea
                    name="description"
                    rows="3"
                    placeholder="Enter department description"
                ><?= e($editDepartment["description"] ?? "") ?></textarea>
            </div>

            <div class="admin-actions">
                <button type="submit" class="admin-btn admin-btn-primary">
                    <?= $editDepartment ? "Update Department" : "Add Department" ?>
                </button>

                <?php if ($editDepartment): ?>
                    <a href="departments.php"
                       class="admin-btn admin-btn-secondary">
                        Cancel
                    </a>
                <?php endif; ?>
            </div>

        </form>
    </section>

    <section class="admin-card">
        <h2>All Departments</h2>

        <div class="admin-table-wrap">
            <table class="admin-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Department</th>
                        <th>Description</th>
                        <th>Doctors</th>
                        <th>Actions</th>
                    </tr>
                </thead>

                <tbody>
                <?php if (count($departments) > 0): ?>

                    <?php foreach ($departments as $department): ?>
                        <tr>
                            <td><?= e($department["id"]) ?></td>

                            <td>
                                <strong>
                                    <?= e($department["department_name"]) ?>
                                </strong>
                            </td>

                            <td>
                                <?= e($department["description"]) ?>
                            </td>

                            <td>
                                <?= e($department["doctor_count"]) ?>
                            </td>

                            <td>
                                <div class="admin-actions">

                                    <a
                                        href="departments.php?edit=<?= (int)$department["id"] ?>"
                                        class="admin-btn admin-btn-secondary"
                                    >
                                        Edit
                                    </a>

                                    <form method="POST"
                                          onsubmit="return confirm('Are you sure you want to delete this department?');">

                                        <input type="hidden"
                                               name="csrf_token"
                                               value="<?= e(csrfToken()) ?>">

                                        <input type="hidden"
                                               name="action"
                                               value="delete">

                                        <input type="hidden"
                                               name="department_id"
                                               value="<?= (int)$department["id"] ?>">

                                        <button type="submit"
                                                class="admin-btn admin-btn-danger">
                                            Delete
                                        </button>
                                    </form>

                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>

                <?php else: ?>

                    <tr>
                        <td colspan="5">No departments found.</td>
                    </tr>

                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </section>

</div>

    <script defer src="../assets/js/script.js"></script>
</body>
</html>
