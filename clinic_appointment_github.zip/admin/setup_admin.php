
<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

$message = '';

$stmt = $pdo->query("SELECT COUNT(*) FROM users WHERE role = 'admin'");
$adminExists = (int)$stmt->fetchColumn() > 0;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !$adminExists) {
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if (!verifyCsrfToken()) {
        $message = 'Your session expired. Please refresh and try again.';
    } elseif ($name === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)
        || strlen($password) < 8) {
        $message = 'Enter a valid name, email and password of at least 8 characters.';
    } else {
        $hash = password_hash($password, PASSWORD_DEFAULT);

        $stmt = $pdo->prepare(
            "INSERT INTO users (name, email, password, role)
             VALUES (?, ?, ?, 'admin')"
        );

        try {
            $stmt->execute([$name, $email, $hash]);
            $message = 'Administrator created. Setup is now locked.';
            $adminExists = true;
        } catch (PDOException $ex) {
            $message = 'Could not create account. The email may already exist.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Administrator Setup</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/premium.css">
</head>
<body class="bg-light">
<div class="container py-5">
<div class="card shadow p-4 mx-auto" style="max-width:450px">
<h3>Clinic Administrator Setup</h3>
<p class="text-muted">Create your first administrator account.</p>
<?php if ($message): ?>
<div class="alert alert-info"><?= htmlspecialchars($message) ?></div>
<?php endif; ?>

<?php if (!$adminExists): ?>
<form method="POST">
<input type="hidden" name="csrf_token" value="<?= htmlspecialchars(csrfToken(), ENT_QUOTES, 'UTF-8') ?>">
<input class="form-control mb-3" name="name" placeholder="Full name" required>
<input class="form-control mb-3" type="email" name="email" placeholder="Email" required>
<input class="form-control mb-3" type="password" name="password" placeholder="Password (8+ characters)" minlength="8" required>
<button class="btn btn-primary w-100">Create Administrator</button>
</form>
<?php else: ?>
<p>Administrator setup is locked.</p>
<a href="../auth/login.php">Go to login</a>
<?php endif; ?>
</div>
</div>
    <script defer src="../assets/js/script.js"></script>
</body>
</html>
