<?php
require_once "../includes/auth_check.php";
require_once "../config/database.php";

requireLogin();

if (($_SESSION["role"] ?? "") !== "admin") {
    http_response_code(403);
    exit("Admin access required.");
}

$message = "";
$messageType = "success";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $doctorId = (int)($_POST["doctor_id"] ?? 0);
    $email = trim($_POST["email"] ?? "");
    $password = $_POST["password"] ?? "";

    if (!verifyCsrfToken()) {
        $message = "Security check failed. Refresh and try again.";
        $messageType = "error";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $message = "Enter a valid email address.";
        $messageType = "error";
    } elseif (strlen($password) < 8) {
        $message = "Password must have at least 8 characters.";
        $messageType = "error";
    } else {
        try {
            $pdo->beginTransaction();

            $stmt = $pdo->prepare(
                "SELECT * FROM doctors WHERE id = ? FOR UPDATE"
            );
            $stmt->execute([$doctorId]);
            $doctor = $stmt->fetch();

            if (!$doctor) {
                throw new Exception("Doctor profile not found.");
            }

            if ($doctor["user_id"] !== null) {
                throw new Exception("This doctor already has an account.");
            }

            $stmt = $pdo->prepare(
                "SELECT id FROM users WHERE email = ?"
            );
            $stmt->execute([$email]);

            if ($stmt->fetch()) {
                throw new Exception("This email is already registered.");
            }

            $hash = password_hash($password, PASSWORD_DEFAULT);

            $stmt = $pdo->prepare("
                INSERT INTO users
                (name, email, password, role)
                VALUES (?, ?, ?, 'doctor')
            ");

            $stmt->execute([
                $doctor["doctor_name"],
                $email,
                $hash
            ]);

            $userId = (int)$pdo->lastInsertId();

            $stmt = $pdo->prepare(
                "UPDATE doctors SET user_id = ? WHERE id = ? AND user_id IS NULL"
            );
            $stmt->execute([$userId, $doctorId]);

            if ($stmt->rowCount() !== 1) {
                throw new Exception("Unable to link doctor account.");
            }

            $pdo->commit();

            $message = "Account successfully created for " .
                $doctor["doctor_name"] . ".";

        } catch (Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }

            $message = $e->getMessage();
            $messageType = "error";
        }
    }
}

$stmt = $pdo->query("
    SELECT id, doctor_name
    FROM doctors
    WHERE user_id IS NULL
    ORDER BY id
");
$doctors = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Create Doctor Accounts | MediCare</title>
<link rel="stylesheet" href="../assets/css/style.css">

<style>
body {
    margin: 0;
    padding: 30px 15px;
    background: #f3f7fb;
    font-family: Arial, sans-serif;
    color: #18344d;
}
.container {
    max-width: 900px;
    margin: auto;
}
h1 { margin-bottom: 8px; }
.subtitle { color: #718096; margin-bottom: 25px; }
.card {
    background: white;
    padding: 25px;
    margin-bottom: 20px;
    border-radius: 15px;
    box-shadow: 0 8px 25px rgba(20,50,75,.08);
}
.card h2 { margin-top: 0; font-size: 20px; }
.card p { color: #718096; }
.form-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 15px;
}
label {
    display: block;
    margin-bottom: 7px;
    font-weight: bold;
    font-size: 14px;
}
input {
    width: 100%;
    box-sizing: border-box;
    padding: 12px;
    border: 1px solid #d7e2eb;
    border-radius: 9px;
}
button {
    grid-column: 1 / -1;
    padding: 14px;
    background: #087f8c;
    color: white;
    border: none;
    border-radius: 9px;
    font-weight: bold;
    cursor: pointer;
}
button:hover { background: #075e68; }
.message {
    padding: 14px;
    border-radius: 9px;
    margin-bottom: 20px;
}
.success { background: #dcfce7; color: #166534; }
.error { background: #fee2e2; color: #991b1b; }
.back {
    display: inline-block;
    margin-bottom: 20px;
    color: #087f8c;
    text-decoration: none;
}
@media(max-width:600px) {
    .form-grid { grid-template-columns: 1fr; }
}
</style>
    <link rel="stylesheet" href="../assets/css/premium.css">
</head>

<body class="admin-page">
<div class="container">

<a class="back" href="doctors.php">← Back to Doctors</a>

<h1>Create Doctor Login Accounts</h1>
<p class="subtitle">
Connect your existing doctor profiles to secure login accounts.
</p>

<?php if ($message): ?>
<div class="message <?= e($messageType) ?>">
    <?= e($message) ?>
</div>
<?php endif; ?>

<?php if ($doctors): ?>

<?php foreach ($doctors as $doctor): ?>
<div class="card">
    <h2><?= e($doctor["doctor_name"]) ?></h2>
    <p>Doctor login access</p>

    <form method="POST" class="form-grid">
        <input type="hidden" name="csrf_token"
               value="<?= e(csrfToken()) ?>">

        <input type="hidden" name="doctor_id"
               value="<?= (int)$doctor["id"] ?>">

        <div>
            <label>Email Address</label>
            <input type="email" name="email" required
                   placeholder="doctor@example.com">
        </div>

        <div>
            <label>Password</label>
            <input type="password" name="password"
                   minlength="8" required
                   placeholder="At least 8 characters">
        </div>

        <button type="submit">Create Doctor Account</button>
    </form>
</div>
<?php endforeach; ?>

<?php else: ?>
<div class="card">
    All doctor profiles have linked accounts!
</div>
<?php endif; ?>

</div>
    <script defer src="../assets/js/script.js"></script>
</body>
</html>
