<?php
require_once "../includes/auth_check.php";
require_once "../config/database.php";

requireRole("admin");

// Dashboard statistics
$totalPatients = $pdo->query(
    "SELECT COUNT(*) FROM users WHERE role = 'patient'"
)->fetchColumn();

$totalDoctors = $pdo->query(
    "SELECT COUNT(*) FROM doctors"
)->fetchColumn();

$totalDepartments = $pdo->query(
    "SELECT COUNT(*) FROM departments"
)->fetchColumn();

$totalAppointments = $pdo->query(
    "SELECT COUNT(*) FROM appointments"
)->fetchColumn();

$pendingAppointments = $pdo->query(
    "SELECT COUNT(*) FROM appointments WHERE status = 'pending'"
)->fetchColumn();

$approvedAppointments = $pdo->query(
    "SELECT COUNT(*) FROM appointments WHERE status = 'approved'"
)->fetchColumn();

$todayAppointments = $pdo->query(
    "SELECT COUNT(*) FROM appointments
     WHERE appointment_date = CURDATE()
       AND status IN ('pending', 'approved', 'completed')"
)->fetchColumn();

$doctorWorkload = $pdo->query(
    "SELECT d.doctor_name, COUNT(a.id) AS appointment_count
     FROM doctors d
     LEFT JOIN appointments a ON a.doctor_id = d.id
     GROUP BY d.id, d.doctor_name
     ORDER BY appointment_count DESC, d.doctor_name"
)->fetchAll();

// Recent appointments
$stmt = $pdo->query("
    SELECT
        a.id,
        a.appointment_date,
        a.appointment_time,
        a.status,
        u.name AS patient_name,
        d.doctor_name
    FROM appointments a
    JOIN users u ON a.patient_id = u.id
    JOIN doctors d ON a.doctor_id = d.id
    ORDER BY a.created_at DESC
    LIMIT 8
");

$recentAppointments = $stmt->fetchAll();

function dashboardStatusClass($status) {
    return match ($status) {
        'approved' => 'success',
        'pending' => 'warning',
        'rejected', 'cancelled' => 'danger',
        'completed' => 'info',
        default => ''
    };
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard | ClinicCare</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/admin.css">

    <style>
        .dashboard-status {
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: bold;
            text-transform: capitalize;
        }
        .dashboard-status.success { background: #e2f7ec; color: #16845b; }
        .dashboard-status.warning { background: #fff3d8; color: #a66a00; }
        .dashboard-status.danger { background: #ffe7e7; color: #c43d45; }
        .dashboard-status.info { background: #e6f2ff; color: #1265a8; }
    </style>
    <link rel="stylesheet" href="../assets/css/premium.css">
</head>
<body>

<div class="admin-page">
    <div class="admin-container">

        <div class="admin-heading">
            <div>
                <h1>Admin Dashboard</h1>
                <p>Welcome back, <?= e($_SESSION['full_name'] ?? 'Administrator') ?>.</p>
            </div>

            <a href="../auth/logout.php" class="admin-btn danger">
                Logout
            </a>
        </div>

        <nav class="admin-nav">
            <a href="dashboard.php" class="active">Dashboard</a>
            <a href="departments.php">Departments</a>
            <a href="doctors.php">Doctors</a>
            <a href="schedules.php">Schedules</a>
            <a href="days_off.php">Days Off</a>
            <a href="appointments.php">Appointments</a>
            <a href="patients.php">Patients</a>
            <a href="visit_notes.php">Visit Notes</a>
            <a href="../index.php">Main Website</a>
        </nav>

        <div class="admin-stats">

            <div class="admin-stat">
                <span>Total Patients</span>
                <strong><?= e($totalPatients) ?></strong>
            </div>

            <div class="admin-stat">
                <span>Total Doctors</span>
                <strong><?= e($totalDoctors) ?></strong>
            </div>

            <div class="admin-stat">
                <span>Departments</span>
                <strong><?= e($totalDepartments) ?></strong>
            </div>

            <div class="admin-stat">
                <span>Total Appointments</span>
                <strong><?= e($totalAppointments) ?></strong>
            </div>

            <div class="admin-stat">
                <span>Pending Appointments</span>
                <strong><?= e($pendingAppointments) ?></strong>
            </div>

            <div class="admin-stat">
                <span>Approved Appointments</span>
                <strong><?= e($approvedAppointments) ?></strong>
            </div>

            <div class="admin-stat">
                <span>Today's Appointments</span>
                <strong><?= e($todayAppointments) ?></strong>
            </div>

        </div>

        <section class="admin-card">
            <h2>Recent Appointments</h2>

            <div class="admin-table-wrap">
                <table class="admin-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Patient</th>
                            <th>Doctor</th>
                            <th>Date</th>
                            <th>Time</th>
                            <th>Status</th>
                        </tr>
                    </thead>

                    <tbody>
                    <?php if ($recentAppointments): ?>

                        <?php foreach ($recentAppointments as $appointment): ?>
                            <tr>
                                <td>#<?= e($appointment['id']) ?></td>
                                <td><?= e($appointment['patient_name']) ?></td>
                                <td><?= e($appointment['doctor_name']) ?></td>
                                <td><?= e($appointment['appointment_date']) ?></td>
                                <td><?= e(date('h:i A', strtotime($appointment['appointment_time']))) ?></td>
                                <td>
                                    <span class="dashboard-status <?= e(dashboardStatusClass($appointment['status'])) ?>">
                                        <?= e($appointment['status']) ?>
                                    </span>
                                </td>
                            </tr>
                        <?php endforeach; ?>

                    <?php else: ?>
                        <tr>
                            <td colspan="6" class="admin-empty">
                                No appointments have been created yet.
                            </td>
                        </tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <br>
            <a href="appointments.php" class="admin-btn primary">
                Manage All Appointments
            </a>
        </section>

        <section class="admin-card">
            <h2>Appointments by Doctor</h2>
            <div class="admin-table-wrap">
                <table class="admin-table">
                    <thead><tr><th>Doctor</th><th>Total Appointments</th></tr></thead>
                    <tbody>
                    <?php if ($doctorWorkload): ?>
                        <?php foreach ($doctorWorkload as $doctor): ?>
                            <tr><td><?= e($doctor['doctor_name']) ?></td><td><?= (int)$doctor['appointment_count'] ?></td></tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr><td colspan="2" class="admin-empty">Add a doctor to see appointment totals.</td></tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </section>

    </div>
</div>

    <script defer src="../assets/js/script.js"></script>
</body>
</html>
