<?php
require_once "../includes/auth_check.php";
require_once "../config/database.php";

requireRole("admin");

$message = "";
$messageType = "success";
$editDoctor = null;

// Handle add, update and delete
if ($_SERVER["REQUEST_METHOD"] === "POST") {

    if (!verifyCsrfToken()) {
        $message = "Security verification failed. Please refresh the page.";
        $messageType = "error";

    } else {

        $action = $_POST["action"] ?? "";

        // ADD OR UPDATE DOCTOR
        if ($action === "save") {

            $doctorId = (int)($_POST["doctor_id"] ?? 0);
            $departmentId = (int)($_POST["department_id"] ?? 0);
            $doctorName = trim($_POST["doctor_name"] ?? "");
            $photo = trim($_POST["photo"] ?? "");
            $fee = (float)($_POST["consultation_fee"] ?? 0);
            $email = strtolower(trim($_POST["email"] ?? ""));
            $password = $_POST["password"] ?? "";

            if ($departmentId <= 0 || $doctorName === "" || $fee < 0) {
                $message = "Please provide a valid doctor name, department and fee.";
                $messageType = "error";

            } elseif ($email !== "" && !filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $message = "Please enter a valid doctor email address.";
                $messageType = "error";

            } elseif ($doctorId === 0 && $email !== "" && strlen($password) < 8) {
                $message = "A new doctor login password must contain at least 8 characters.";
                $messageType = "error";

            } elseif ($doctorId > 0 && $password !== "" && strlen($password) < 8) {
                $message = "The new password must contain at least 8 characters.";
                $messageType = "error";

            } else {

                try {
                    $pdo->beginTransaction();

                    // Confirm department exists
                    $checkDepartment = $pdo->prepare(
                        "SELECT id FROM departments WHERE id = ?"
                    );
                    $checkDepartment->execute([$departmentId]);

                    if (!$checkDepartment->fetch()) {
                        throw new Exception("Please select a valid department.");
                    }

                    if ($doctorId > 0) {

                        // Find current doctor record
                        $findDoctor = $pdo->prepare(
                            "SELECT * FROM doctors WHERE id = ?"
                        );
                        $findDoctor->execute([$doctorId]);
                        $currentDoctor = $findDoctor->fetch();

                        if (!$currentDoctor) {
                            throw new Exception("Doctor record not found.");
                        }

                        $userId = $currentDoctor["user_id"];

                        // Update existing doctor login if one is linked
                        if ($userId) {

                            if ($email !== "") {
                                $checkEmail = $pdo->prepare(
                                    "SELECT id FROM users WHERE email = ? AND id != ?"
                                );
                                $checkEmail->execute([$email, $userId]);

                                if ($checkEmail->fetch()) {
                                    throw new Exception("This email is already registered.");
                                }

                                if ($password !== "") {
                                    $updateUser = $pdo->prepare("
                                        UPDATE users
                                        SET email = ?, password = ?
                                        WHERE id = ?
                                    ");
                                    $updateUser->execute([
                                        $email,
                                        password_hash($password, PASSWORD_DEFAULT),
                                        $userId
                                    ]);
                                } else {
                                    $updateUser = $pdo->prepare("
                                        UPDATE users SET email = ? WHERE id = ?
                                    ");
                                    $updateUser->execute([$email, $userId]);
                                }
                            }

                        } elseif ($email !== "") {

                            // Create a login account for an existing doctor
                            $checkEmail = $pdo->prepare(
                                "SELECT id FROM users WHERE email = ?"
                            );
                            $checkEmail->execute([$email]);

                            if ($checkEmail->fetch()) {
                                throw new Exception("This email is already registered.");
                            }

                            $createUser = $pdo->prepare("
                                INSERT INTO users (name, email, password, role)
                                VALUES (?, ?, ?, 'doctor')
                            ");

                            $createUser->execute([
                                $doctorName,
                                $email,
                                password_hash($password, PASSWORD_DEFAULT)
                            ]);

                            $userId = (int)$pdo->lastInsertId();
                        }

                        // Update doctor record
                        $updateDoctor = $pdo->prepare("
                            UPDATE doctors
                            SET department_id = ?,
                                doctor_name = ?,
                                photo = ?,
                                fee = ?,
                                user_id = ?
                            WHERE id = ?
                        ");

                        $updateDoctor->execute([
                            $departmentId,
                            $doctorName,
                            $photo,
                            $fee,
                            $userId,
                            $doctorId
                        ]);

                        // Keep linked account display name synchronized
                        if ($userId) {
                            $updateName = $pdo->prepare(
                                "UPDATE users SET name = ? WHERE id = ?"
                            );
                            $updateName->execute([$doctorName, $userId]);
                        }

                        $message = "Doctor information updated successfully.";

                    } else {

                        $userId = null;

                        // Create optional doctor login
                        if ($email !== "") {

                            $checkEmail = $pdo->prepare(
                                "SELECT id FROM users WHERE email = ?"
                            );
                            $checkEmail->execute([$email]);

                            if ($checkEmail->fetch()) {
                                throw new Exception("This email is already registered.");
                            }

                            $createUser = $pdo->prepare("
                                INSERT INTO users (name, email, password, role)
                                VALUES (?, ?, ?, 'doctor')
                            ");

                            $createUser->execute([
                                $doctorName,
                                $email,
                                password_hash($password, PASSWORD_DEFAULT)
                            ]);

                            $userId = (int)$pdo->lastInsertId();
                        }

                        $insertDoctor = $pdo->prepare("
                            INSERT INTO doctors
                            (
                                department_id,
                                doctor_name,
                                photo,
                                fee,
                                user_id
                            )
                            VALUES (?, ?, ?, ?, ?)
                        ");

                        $insertDoctor->execute([
                            $departmentId,
                            $doctorName,
                            $photo,
                            $fee,
                            $userId
                        ]);

                        $message = "Doctor added successfully.";
                    }

                    $pdo->commit();

                } catch (Exception $e) {
                    if ($pdo->inTransaction()) {
                        $pdo->rollBack();
                    }

                    $message = $e instanceof PDOException
                        ? "Unable to save the doctor. Please check the information."
                        : $e->getMessage();

                    $messageType = "error";
                }
            }

        // DELETE DOCTOR
        } elseif ($action === "delete") {

            $doctorId = (int)($_POST["doctor_id"] ?? 0);

            try {
                $check = $pdo->prepare("
                    SELECT
                        (SELECT COUNT(*) FROM appointments WHERE doctor_id = ?) AS appointments_count,
                        (SELECT COUNT(*) FROM doctor_schedules WHERE doctor_id = ?) AS schedules_count,
                        (SELECT COUNT(*) FROM days_off WHERE doctor_id = ?) AS days_off_count
                ");

                $check->execute([$doctorId, $doctorId, $doctorId]);
                $usage = $check->fetch();

                if (
                    $usage["appointments_count"] > 0 ||
                    $usage["schedules_count"] > 0 ||
                    $usage["days_off_count"] > 0
                ) {
                    throw new Exception(
                        "This doctor has appointments or schedules. Remove those records first."
                    );
                }

                $delete = $pdo->prepare("DELETE FROM doctors WHERE id = ?");
                $delete->execute([$doctorId]);

                $message = "Doctor record deleted successfully.";

            } catch (Exception $e) {
                $message = $e instanceof PDOException
                    ? "Unable to delete this doctor because another record is connected to it."
                    : $e->getMessage();

                $messageType = "error";
            }
        }
    }
}

// Load doctor for editing
if (isset($_GET["edit"])) {

    $id = (int)$_GET["edit"];

    $stmt = $pdo->prepare("
        SELECT d.*, d.fee AS consultation_fee, u.email
        FROM doctors d
        LEFT JOIN users u ON d.user_id = u.id
        WHERE d.id = ?
    ");

    $stmt->execute([$id]);
    $editDoctor = $stmt->fetch();
}

// Load departments
$departments = $pdo->query("
    SELECT id, department_name
    FROM departments
    ORDER BY department_name
")->fetchAll();

// Load doctors
$doctors = $pdo->query("
    SELECT
        d.*,
        d.fee AS consultation_fee,
        dep.department_name,
        u.email AS login_email
    FROM doctors d
    JOIN departments dep ON d.department_id = dep.id
    LEFT JOIN users u ON d.user_id = u.id
    ORDER BY d.id DESC
")->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Doctor Management | ClinicCare</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/admin.css">
    <link rel="stylesheet" href="../assets/css/premium.css">
</head>
<body class="admin-page">

<div class="admin-page">
<div class="admin-container">

    <div class="admin-heading">
        <div>
            <h1>Doctor Management</h1>
            <p>Add doctors, assign departments and manage their information.</p>
        </div>
        <a href="dashboard.php" class="admin-btn secondary">Back to Dashboard</a>
    </div>

    <nav class="admin-nav">
        <a href="dashboard.php">Dashboard</a>
        <a href="departments.php">Departments</a>
        <a href="doctors.php" class="active">Doctors</a>
        <a href="schedules.php">Schedules</a>
        <a href="days_off.php">Days Off</a>
        <a href="appointments.php">Appointments</a>
        <a href="patients.php">Patients</a>
        <a href="visit_notes.php">Visit Notes</a>
    </nav>

    <?php if ($message): ?>
        <div class="admin-alert <?= e($messageType) ?>">
            <?= e($message) ?>
        </div>
    <?php endif; ?>

    <section class="admin-card">
        <h2><?= $editDoctor ? "Edit Doctor" : "Add New Doctor" ?></h2>

        <?php if (!$departments): ?>
            <div class="admin-alert error">
                Please create a department before adding a doctor.
                <a href="departments.php">Manage Departments</a>
            </div>
        <?php else: ?>

        <form method="POST" class="admin-form">

            <input type="hidden" name="csrf_token" value="<?= e(csrfToken()) ?>">
            <input type="hidden" name="action" value="save">
            <input type="hidden" name="doctor_id"
                   value="<?= e($editDoctor['id'] ?? 0) ?>">

            <div class="admin-field">
                <label>Doctor Name *</label>
                <input type="text" name="doctor_name"
                       value="<?= e($editDoctor['doctor_name'] ?? '') ?>"
                       placeholder="Enter doctor's full name" required>
            </div>

            <div class="admin-field">
                <label>Department *</label>
                <select name="department_id" required>
                    <option value="">Select Department</option>

                    <?php foreach ($departments as $department): ?>
                        <option value="<?= e($department['id']) ?>"
                            <?= (isset($editDoctor['department_id']) &&
                                $editDoctor['department_id'] == $department['id'])
                                ? 'selected' : '' ?>>
                            <?= e($department['department_name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="admin-field">
                <label>Consultation Fee (MMK) *</label>
                <input type="number" name="consultation_fee"
                       min="0" step="0.01"
                       value="<?= e($editDoctor['consultation_fee'] ?? '0') ?>"
                       required>
            </div>

            <div class="admin-field">
                <label>Photo Path or Image URL</label>
                <input type="text" name="photo"
                       value="<?= e($editDoctor['photo'] ?? '') ?>"
                       placeholder="assets/images/doctor.jpg">
            </div>

            <div class="admin-field">
                <label>Login Email <?= $editDoctor ? "(optional)" : "(optional)" ?></label>
                <input type="email" name="email"
                       value="<?= e($editDoctor['email'] ?? '') ?>"
                       placeholder="doctor@example.com">
            </div>

            <div class="admin-field">
                <label>
                    <?= $editDoctor ? "New Password (leave blank to keep current)" : "Login Password (minimum 8 characters if email is entered)" ?>
                </label>
                <input type="password" name="password"
                       minlength="8"
                       placeholder="Enter a login password">
            </div>

            <div class="admin-field full">
                <div class="admin-actions">
                    <button type="submit" class="admin-btn primary">
                        <?= $editDoctor ? "Update Doctor" : "Add Doctor" ?>
                    </button>

                    <?php if ($editDoctor): ?>
                        <a href="doctors.php" class="admin-btn secondary">
                            Cancel Edit
                        </a>
                    <?php endif; ?>
                </div>
            </div>

        </form>

        <?php endif; ?>
    </section>

    <section class="admin-card">
        <h2>Registered Doctors (<?= count($doctors) ?>)</h2>

        <div class="admin-table-wrap">
            <table class="admin-table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Doctor</th>
                        <th>Department</th>
                        <th>Fee (MMK)</th>
                        <th>Login Account</th>
                        <th>Actions</th>
                    </tr>
                </thead>

                <tbody>
                <?php if ($doctors): ?>

                    <?php foreach ($doctors as $doctor): ?>
                        <tr>
                            <td><?= e($doctor['id']) ?></td>

                            <td>
                                <strong><?= e($doctor['doctor_name']) ?></strong>
                            </td>

                            <td><?= e($doctor['department_name']) ?></td>

                            <td><?= e(number_format((float)$doctor['consultation_fee'], 2)) ?></td>

                            <td>
                                <?php if ($doctor['login_email']): ?>
                                    <span class="admin-badge">Account created</span>
                                    <br>
                                    <small><?= e($doctor['login_email']) ?></small>
                                <?php else: ?>
                                    <span class="admin-badge">No login</span>
                                <?php endif; ?>
                            </td>

                            <td>
                                <div class="admin-actions">
                                    <a href="doctors.php?edit=<?= e($doctor['id']) ?>"
                                       class="admin-btn secondary">Edit</a>

                                    <form method="POST"
                                          onsubmit="return confirm('Delete this doctor record?');">
                                        <input type="hidden" name="csrf_token"
                                               value="<?= e(csrfToken()) ?>">
                                        <input type="hidden" name="action" value="delete">
                                        <input type="hidden" name="doctor_id"
                                               value="<?= e($doctor['id']) ?>">

                                        <button type="submit" class="admin-btn danger">
                                            Delete
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>

                <?php else: ?>
                    <tr>
                        <td colspan="6" class="admin-empty">
                            No doctors have been added yet.
                        </td>
                    </tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </section>

</div>
</div>

    <script defer src="../assets/js/script.js"></script>
</body>
</html>
