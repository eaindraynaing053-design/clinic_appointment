
<?php
require_once "../includes/auth_check.php";
require_once "../config/database.php";
requireRole("admin");

$message = "";
$messageType = "success";

// Handle form submissions
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    if (!verifyCsrfToken()) {
        $message = "Your session expired. Please refresh and try again.";
        $messageType = "error";
    } else {
    $action = $_POST["action"] ?? "";

    if ($action === "save") {
        $id = (int)($_POST["days_off_id"] ?? 0);
        $doctorId = (int)($_POST["doctor_id"] ?? 0);
        $startDate = $_POST["start_date"] ?? "";
        $endDate = $_POST["end_date"] ?? "";
        $reason = trim($_POST["reason"] ?? "");

        if (
            $doctorId <= 0 ||
            !$startDate ||
            !$endDate ||
            $startDate > $endDate
        ) {
            $message = "Please enter valid doctor and leave dates.";
            $messageType = "error";
        } else {
            if ($id > 0) {
                $stmt = $pdo->prepare(
                    "UPDATE days_off
                     SET doctor_id = ?, start_date = ?,
                         end_date = ?, reason = ?
                     WHERE id = ?"
                );

                $stmt->execute([
                    $doctorId, $startDate, $endDate, $reason, $id
                ]);

                $message = "Doctor leave record updated successfully.";
            } else {
                $stmt = $pdo->prepare(
                    "INSERT INTO days_off
                     (doctor_id, start_date, end_date, reason)
                     VALUES (?, ?, ?, ?)"
                );

                $stmt->execute([
                    $doctorId, $startDate, $endDate, $reason
                ]);

                $message = "Doctor leave record added successfully.";
            }
        }
    }

    if ($action === "delete") {
        $id = (int)($_POST["days_off_id"] ?? 0);

        $stmt = $pdo->prepare(
            "DELETE FROM days_off WHERE id = ?"
        );
        $stmt->execute([$id]);

        $message = "Leave record deleted successfully.";
    }
    }
}

// Get doctors
$doctors = $pdo->query(
    "SELECT id, doctor_name
     FROM doctors
     ORDER BY doctor_name"
)->fetchAll();

// Get leave records
$stmt = $pdo->query(
    "SELECT days_off.*, doctors.doctor_name
     FROM days_off
     JOIN doctors ON days_off.doctor_id = doctors.id
     ORDER BY days_off.start_date DESC"
);
$daysOffRecords = $stmt->fetchAll();

// Get record for editing
$editRecord = null;

if (isset($_GET["edit"])) {
    $stmt = $pdo->prepare(
        "SELECT * FROM days_off WHERE id = ?"
    );
    $stmt->execute([(int)$_GET["edit"]]);
    $editRecord = $stmt->fetch();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Doctor Days Off | Clinic Admin</title>

    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/admin.css">
    <link rel="stylesheet" href="../assets/css/premium.css">
</head>

<body class="admin-page">

<div class="admin-container">

    <div class="admin-heading">
        <div>
            <h1>Doctor Days Off Management</h1>
            <p>Manage doctor holidays, leave periods and unavailable dates.</p>
        </div>

        <a href="dashboard.php"
           class="admin-btn admin-btn-secondary">
            Back to Dashboard
        </a>
    </div>

    <nav class="admin-nav">
        <a href="dashboard.php">Dashboard</a>
        <a href="departments.php">Departments</a>
        <a href="doctors.php">Doctors</a>
        <a href="schedules.php">Schedules</a>
        <a href="days_off.php">Days Off</a>
        <a href="appointments.php">Appointments</a>
        <a href="patients.php">Patients</a>
        <a href="../auth/logout.php">Logout</a>
    </nav>

    <?php if ($message): ?>
        <div class="admin-alert">
            <?= htmlspecialchars($message) ?>
        </div>
    <?php endif; ?>

    <section class="admin-card">

        <h2>
            <?= $editRecord ? "Edit Doctor Leave" : "Add Doctor Leave" ?>
        </h2>

        <?php if (!$doctors): ?>

            <p>Please add a doctor before creating a leave record.</p>

        <?php else: ?>

        <form method="POST" class="admin-form">
            <input type="hidden" name="csrf_token" value="<?= e(csrfToken()) ?>">

            <input type="hidden" name="action" value="save">

            <input type="hidden" name="days_off_id"
                   value="<?= (int)($editRecord["id"] ?? 0) ?>">

            <div class="admin-field">
                <label>Select Doctor</label>

                <select name="doctor_id" required>
                    <option value="">Choose a doctor</option>

                    <?php foreach ($doctors as $doctor): ?>
                        <option value="<?= (int)$doctor["id"] ?>"
                            <?= ($editRecord &&
                                $editRecord["doctor_id"] == $doctor["id"])
                                ? "selected" : "" ?>>

                            <?= htmlspecialchars($doctor["doctor_name"]) ?>

                        </option>
                    <?php endforeach; ?>

                </select>
            </div>

            <div class="admin-field">
                <label>Leave Start Date</label>

                <input type="date"
                       name="start_date"
                       value="<?= htmlspecialchars($editRecord["start_date"] ?? "") ?>"
                       required>
            </div>

            <div class="admin-field">
                <label>Leave End Date</label>

                <input type="date"
                       name="end_date"
                       value="<?= htmlspecialchars($editRecord["end_date"] ?? "") ?>"
                       required>
            </div>

            <div class="admin-field">
                <label>Reason for Leave</label>

                <input type="text"
                       name="reason"
                       placeholder="e.g. Annual leave, Personal leave"
                       value="<?= htmlspecialchars($editRecord["reason"] ?? "") ?>">
            </div>

            <div class="admin-actions">

                <button type="submit"
                        class="admin-btn admin-btn-primary">

                    <?= $editRecord ? "Update Leave" : "Save Leave" ?>

                </button>

                <?php if ($editRecord): ?>
                    <a href="days_off.php"
                       class="admin-btn admin-btn-secondary">
                        Cancel
                    </a>
                <?php endif; ?>

            </div>

        </form>

        <?php endif; ?>

    </section>

    <section class="admin-card">

        <h2>All Doctor Leave Records</h2>

        <div class="admin-table-wrap">

            <table class="admin-table">

                <thead>
                    <tr>
                        <th>No.</th>
                        <th>Doctor</th>
                        <th>Start Date</th>
                        <th>End Date</th>
                        <th>Reason</th>
                        <th>Actions</th>
                    </tr>
                </thead>

                <tbody>

                <?php if (!$daysOffRecords): ?>

                    <tr>
                        <td colspan="6">No leave records found.</td>
                    </tr>

                <?php else: ?>

                    <?php foreach ($daysOffRecords as $index => $record): ?>

                        <tr>
                            <td><?= $index + 1 ?></td>

                            <td>
                                <?= htmlspecialchars($record["doctor_name"]) ?>
                            </td>

                            <td>
                                <?= date("d M Y", strtotime($record["start_date"])) ?>
                            </td>

                            <td>
                                <?= date("d M Y", strtotime($record["end_date"])) ?>
                            </td>

                            <td>
                                <?= htmlspecialchars($record["reason"] ?? "Not specified") ?>
                            </td>

                            <td>
                                <div class="admin-actions">

                                    <a href="?edit=<?= (int)$record["id"] ?>"
                                       class="admin-btn admin-btn-secondary">
                                        Edit
                                    </a>

                                    <form method="POST"
                                          onsubmit="return confirm('Delete this leave record?');">
                                        <input type="hidden" name="csrf_token" value="<?= e(csrfToken()) ?>">

                                        <input type="hidden"
                                               name="action"
                                               value="delete">

                                        <input type="hidden"
                                               name="days_off_id"
                                               value="<?= (int)$record["id"] ?>">

                                        <button type="submit"
                                                class="admin-btn admin-btn-danger">
                                            Delete
                                        </button>

                                    </form>

                                </div>
                            </td>
                        </tr>

                    <?php endforeach; ?>

                <?php endif; ?>

                </tbody>

            </table>

        </div>

    </section>

</div>

    <script defer src="../assets/js/script.js"></script>
</body>
</html>
