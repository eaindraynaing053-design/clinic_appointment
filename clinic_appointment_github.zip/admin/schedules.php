
<?php
require_once "../includes/auth_check.php";
require_once "../config/database.php";
requireRole("admin");

$message = "";
$messageType = "success";
$weekdays = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"];

// Save or update schedule
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    if (!verifyCsrfToken()) {
        $message = "Your session expired. Please refresh and try again.";
        $messageType = "error";
    } else {
    $action = $_POST["action"] ?? "";

    if ($action === "save") {
        $scheduleId = (int)($_POST["schedule_id"] ?? 0);
        $doctorId = (int)($_POST["doctor_id"] ?? 0);
        $day = $_POST["day_of_week"] ?? "";
        $start = $_POST["start_time"] ?? "";
        $end = $_POST["end_time"] ?? "";
        $duration = (int)($_POST["slot_duration"] ?? 30);

        $dayIndex = array_search($day, $weekdays, true);
        $dayNumber = $dayIndex === false ? 0 : $dayIndex + 1;

        if (
            $doctorId <= 0 ||
            !in_array($day, $weekdays, true) ||
            $start === "" || $end === "" ||
            $start >= $end ||
            $duration <= 0
        ) {
            $message = "Please enter valid schedule information.";
            $messageType = "error";
        } else {
            if ($scheduleId > 0) {
                $stmt = $pdo->prepare(
                    "UPDATE doctor_schedules
                     SET doctor_id=?, day_of_week=?,
                         start_time=?, end_time=?, slot_minutes=?
                     WHERE id=?"
                );
                $stmt->execute([
                    $doctorId, $dayNumber, $start, $end,
                    $duration, $scheduleId
                ]);
                $message = "Schedule updated successfully.";
            } else {
                $stmt = $pdo->prepare(
                    "INSERT INTO doctor_schedules
                     (doctor_id, day_of_week, start_time,
                      end_time, slot_minutes)
                     VALUES (?, ?, ?, ?, ?)"
                );
                $stmt->execute([
                    $doctorId, $dayNumber, $start, $end, $duration
                ]);
                $message = "Schedule added successfully.";
            }
        }
    }

    if ($action === "delete") {
        $scheduleId = (int)($_POST["schedule_id"] ?? 0);

        $stmt = $pdo->prepare(
            "DELETE FROM doctor_schedules WHERE id=?"
        );
        $stmt->execute([$scheduleId]);

        $message = "Schedule deleted successfully.";
    }
    }
}

// Load doctors
$doctors = $pdo->query(
    "SELECT id, doctor_name FROM doctors ORDER BY doctor_name"
)->fetchAll();

// Load schedules
$schedules = $pdo->query(
    "SELECT s.*, s.slot_minutes AS slot_duration,
            CASE s.day_of_week
              WHEN 1 THEN 'Monday' WHEN 2 THEN 'Tuesday'
              WHEN 3 THEN 'Wednesday' WHEN 4 THEN 'Thursday'
              WHEN 5 THEN 'Friday' WHEN 6 THEN 'Saturday'
              WHEN 7 THEN 'Sunday' END AS day_name,
            d.doctor_name
     FROM doctor_schedules s
     JOIN doctors d ON s.doctor_id = d.id
     ORDER BY d.doctor_name, s.day_of_week"
)->fetchAll();

// Edit record
$editSchedule = null;

if (isset($_GET["edit"])) {
    $stmt = $pdo->prepare(
        "SELECT *, slot_minutes AS slot_duration,
                CASE day_of_week
                  WHEN 1 THEN 'Monday' WHEN 2 THEN 'Tuesday'
                  WHEN 3 THEN 'Wednesday' WHEN 4 THEN 'Thursday'
                  WHEN 5 THEN 'Friday' WHEN 6 THEN 'Saturday'
                  WHEN 7 THEN 'Sunday' END AS day_name
         FROM doctor_schedules WHERE id=?"
    );
    $stmt->execute([(int)$_GET["edit"]]);
    $editSchedule = $stmt->fetch();
    if ($editSchedule) {
        $editSchedule['day_of_week'] = $editSchedule['day_name'];
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Doctor Schedules | Clinic Admin</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/admin.css">
    <link rel="stylesheet" href="../assets/css/premium.css">
</head>
<body class="admin-page">

<div class="admin-container">

    <div class="admin-heading">
        <div>
            <h1>Doctor Schedule Management</h1>
            <p>Manage doctors' weekly working hours and appointment slots.</p>
        </div>
        <a href="dashboard.php" class="admin-btn admin-btn-secondary">
            Back to Dashboard
        </a>
    </div>

    <nav class="admin-nav">
        <a href="dashboard.php">Dashboard</a>
        <a href="departments.php">Departments</a>
        <a href="doctors.php">Doctors</a>
        <a href="schedules.php">Schedules</a>
        <a href="days_off.php">Days Off</a>
        <a href="appointments.php">Appointments</a>
        <a href="patients.php">Patients</a>
        <a href="../auth/logout.php">Logout</a>
    </nav>

    <?php if ($message): ?>
        <div class="admin-alert">
            <?= htmlspecialchars($message) ?>
        </div>
    <?php endif; ?>

    <section class="admin-card">
        <h2><?= $editSchedule ? "Edit Schedule" : "Add Weekly Schedule" ?></h2>

        <?php if (count($doctors) === 0): ?>
            <p>No doctors available. Add a doctor first.</p>
        <?php else: ?>

        <form method="POST" class="admin-form">
            <input type="hidden" name="csrf_token" value="<?= e(csrfToken()) ?>">
            <input type="hidden" name="action" value="save">
            <input type="hidden" name="schedule_id"
                   value="<?= (int)($editSchedule["id"] ?? 0) ?>">

            <div class="admin-field">
                <label>Doctor</label>
                <select name="doctor_id" required>
                    <option value="">Select Doctor</option>
                    <?php foreach ($doctors as $doctor): ?>
                        <option value="<?= $doctor["id"] ?>"
                            <?= ($editSchedule &&
                                $editSchedule["doctor_id"] == $doctor["id"])
                                ? "selected" : "" ?>>
                            <?= htmlspecialchars($doctor["doctor_name"]) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="admin-field">
                <label>Working Day</label>
                <select name="day_of_week" required>
                    <?php
                    foreach ($weekdays as $day):
                    ?>
                        <option value="<?= $day ?>"
                            <?= (($editSchedule["day_of_week"] ?? "") === $day)
                                ? "selected" : "" ?>>
                            <?= $day ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="admin-field">
                <label>Start Time</label>
                <input type="time" name="start_time"
                    value="<?= htmlspecialchars($editSchedule["start_time"] ?? "09:00") ?>"
                    required>
            </div>

            <div class="admin-field">
                <label>End Time</label>
                <input type="time" name="end_time"
                    value="<?= htmlspecialchars($editSchedule["end_time"] ?? "12:00") ?>"
                    required>
            </div>

            <div class="admin-field">
                <label>Slot Duration (minutes)</label>
                <select name="slot_duration">
                    <?php foreach ([15, 20, 30, 45, 60] as $minutes): ?>
                        <option value="<?= $minutes ?>"
                            <?= (int)($editSchedule["slot_duration"] ?? 30) === $minutes
                                ? "selected" : "" ?>>
                            <?= $minutes ?> minutes
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="admin-actions">
                <button type="submit" class="admin-btn admin-btn-primary">
                    <?= $editSchedule ? "Update Schedule" : "Save Schedule" ?>
                </button>

                <?php if ($editSchedule): ?>
                    <a href="schedules.php"
                       class="admin-btn admin-btn-secondary">Cancel</a>
                <?php endif; ?>
            </div>
        </form>
        <?php endif; ?>
    </section>

    <section class="admin-card">
        <h2>All Doctor Schedules</h2>

        <div class="admin-table-wrap">
            <table class="admin-table">
                <thead>
                    <tr>
                        <th>No.</th>
                        <th>Doctor</th>
                        <th>Day</th>
                        <th>Start</th>
                        <th>End</th>
                        <th>Slot Duration</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                <?php if (!$schedules): ?>
                    <tr>
                        <td colspan="7">No schedules have been added yet.</td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($schedules as $index => $schedule): ?>
                        <tr>
                            <td><?= $index + 1 ?></td>
                            <td><?= htmlspecialchars($schedule["doctor_name"]) ?></td>
                            <td><?= htmlspecialchars($schedule["day_name"]) ?></td>
                            <td><?= date("g:i A", strtotime($schedule["start_time"])) ?></td>
                            <td><?= date("g:i A", strtotime($schedule["end_time"])) ?></td>
                            <td><?= (int)$schedule["slot_duration"] ?> min</td>
                            <td>
                                <div class="admin-actions">
                                    <a class="admin-btn admin-btn-secondary"
                                       href="?edit=<?= $schedule["id"] ?>">
                                        Edit
                                    </a>

                                    <form method="POST"
                                          onsubmit="return confirm('Delete this schedule?');">
                                        <input type="hidden" name="csrf_token" value="<?= e(csrfToken()) ?>">
                                        <input type="hidden" name="action" value="delete">
                                        <input type="hidden" name="schedule_id"
                                               value="<?= $schedule["id"] ?>">
                                        <button type="submit"
                                                class="admin-btn admin-btn-danger">
                                            Delete
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </section>

</div>
    <script defer src="../assets/js/script.js"></script>
</body>
</html>
