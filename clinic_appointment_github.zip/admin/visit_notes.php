
<?php
require_once "../includes/auth_check.php";
require_once "../config/database.php";
requireRole("admin");

$message = '';
$messageType = 'success';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $appointmentId = (int)($_POST['appointment_id'] ?? 0);
    $visitNote = trim($_POST['visit_note'] ?? '');
    $prescription = trim($_POST['prescription'] ?? '');
    if (!verifyCsrfToken()) {
        $message = 'Your session expired. Please refresh and try again.';
        $messageType = 'error';
    } elseif ($appointmentId <= 0 || $visitNote === '') {
        $message = 'Choose a completed appointment and enter a visit note.';
        $messageType = 'error';
    } else {
        $appointmentQuery = $pdo->prepare("SELECT doctor_id, patient_id FROM appointments WHERE id = ? AND status = 'completed'");
        $appointmentQuery->execute([$appointmentId]);
        $completedAppointment = $appointmentQuery->fetch();
        if (!$completedAppointment) {
            $message = 'Only completed appointments can receive visit notes.';
            $messageType = 'error';
        } else {
            try {
                $insert = $pdo->prepare('INSERT INTO visit_notes (appointment_id, doctor_id, notes, prescription) VALUES (?, ?, ?, ?)');
                $insert->execute([$appointmentId, $completedAppointment['doctor_id'], $visitNote, $prescription]);
                $message = 'Visit note saved. The patient can now see it in medical history.';
            } catch (PDOException $exception) {
                $message = $exception->getCode() === '23000'
                    ? 'A visit note already exists for that appointment.'
                    : 'Could not save the visit note. Please try again.';
                $messageType = 'error';
            }
        }
    }
}

$completedWithoutNotes = $pdo->query("SELECT a.id, a.appointment_date, a.appointment_time, u.name AS patient_name, d.doctor_name FROM appointments a JOIN users u ON a.patient_id = u.id JOIN doctors d ON a.doctor_id = d.id WHERE a.status = 'completed' AND a.id NOT IN (SELECT appointment_id FROM visit_notes) ORDER BY a.appointment_date DESC, a.appointment_time DESC")->fetchAll();

$stmt = $pdo->query(
    "SELECT
        vn.id,
        vn.notes AS visit_note,
        vn.prescription,
        vn.created_at,
        u.name AS patient_name,
        d.doctor_name,
        a.appointment_date,
        a.appointment_time
     FROM visit_notes vn
     JOIN appointments a ON vn.appointment_id = a.id
     JOIN users u ON a.patient_id = u.id
     JOIN doctors d ON vn.doctor_id = d.id
     ORDER BY vn.created_at DESC"
);

$visitNotes = $stmt->fetchAll();

$totalNotes = count($visitNotes);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Visit Notes | Clinic Admin</title>

    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/admin.css">
    <link rel="stylesheet" href="../assets/css/premium.css">
</head>
<body class="admin-page">

<div class="admin-container">

    <div class="admin-heading">
        <div>
            <h1>Visit Notes Management</h1>
            <p>View consultation records and prescriptions.</p>
        </div>

        <a href="dashboard.php" class="admin-btn admin-btn-secondary">
            Back to Dashboard
        </a>
    </div>

    <nav class="admin-nav">
        <a href="dashboard.php">Dashboard</a>
        <a href="departments.php">Departments</a>
        <a href="doctors.php">Doctors</a>
        <a href="schedules.php">Schedules</a>
        <a href="days_off.php">Days Off</a>
        <a href="appointments.php">Appointments</a>
        <a href="patients.php">Patients</a>
        <a href="visit_notes.php">Visit Notes</a>
        <a href="../auth/logout.php">Logout</a>
    </nav>

    <?php if ($message): ?>
        <div class="admin-alert <?= $messageType === 'error' ? 'error' : 'success' ?>"><?= e($message) ?></div>
    <?php endif; ?>

    <section class="admin-card">
        <h2>Add a visit note</h2>
        <?php if ($completedWithoutNotes): ?>
            <form method="POST" style="display:grid;gap:14px;max-width:760px">
                <input type="hidden" name="csrf_token" value="<?= e(csrfToken()) ?>">
                <label>Completed appointment
                    <select name="appointment_id" required>
                        <option value="">Choose a patient visit</option>
                        <?php foreach ($completedWithoutNotes as $visit): ?>
                            <option value="<?= (int)$visit['id'] ?>"><?= e($visit['patient_name']) ?> — Dr. <?= e($visit['doctor_name']) ?>, <?= date('d M Y', strtotime($visit['appointment_date'])) ?> <?= date('g:i A', strtotime($visit['appointment_time'])) ?></option>
                        <?php endforeach; ?>
                    </select>
                </label>
                <label>Visit note
                    <textarea name="visit_note" rows="4" maxlength="5000" required placeholder="Brief consultation summary"></textarea>
                </label>
                <label>Prescription or care instructions (optional)
                    <textarea name="prescription" rows="3" maxlength="5000" placeholder="Medication and follow-up guidance"></textarea>
                </label>
                <button type="submit" class="admin-btn admin-btn-primary">Save Visit Note</button>
            </form>
        <?php else: ?>
            <p>No completed appointments are waiting for a visit note.</p>
        <?php endif; ?>
    </section>

    <section class="admin-stats">
        <div class="admin-stat">
            <h3>Total Consultation Records</h3>
            <p><?= $totalNotes ?></p>
        </div>
    </section>

    <section class="admin-card">
        <h2>Patient Consultation Records</h2>

        <div class="admin-table-wrap">
            <table class="admin-table">
                <thead>
                    <tr>
                        <th>No.</th>
                        <th>Patient</th>
                        <th>Doctor</th>
                        <th>Appointment Date</th>
                        <th>Visit Notes</th>
                        <th>Prescription</th>
                        <th>Record Created</th>
                    </tr>
                </thead>

                <tbody>
                <?php if (!$visitNotes): ?>
                    <tr>
                        <td colspan="7">No consultation records found.</td>
                    </tr>
                <?php else: ?>

                    <?php foreach ($visitNotes as $index => $note): ?>
                        <tr>
                            <td><?= $index + 1 ?></td>

                            <td><?= htmlspecialchars($note["patient_name"]) ?></td>

                            <td><?= htmlspecialchars($note["doctor_name"]) ?></td>

                            <td>
                                <?= date("d M Y", strtotime($note["appointment_date"])) ?>
                                <br>
                                <?= date("g:i A", strtotime($note["appointment_time"])) ?>
                            </td>

                            <td>
                                <?= nl2br(htmlspecialchars($note["visit_note"] ?? "")) ?>
                            </td>

                            <td>
                                <?= nl2br(htmlspecialchars($note["prescription"] ?? "")) ?>
                            </td>

                            <td>
                                <?= date("d M Y, g:i A", strtotime($note["created_at"])) ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>

                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </section>

</div>
    <script defer src="../assets/js/script.js"></script>
</body>
</html>
