
<?php
require_once __DIR__ . "/../includes/auth_check.php";
require_once __DIR__ . "/../config/database.php";
requireRole("admin");

$message = "";
$messageType = "success";

// Handle appointment status changes
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $appointmentId = (int)($_POST["appointment_id"] ?? 0);
    $action = $_POST["action"] ?? "";
    $reason = trim($_POST["rejection_reason"] ?? "");

    $allowedActions = [
        "approve" => "approved",
        "reject" => "rejected",
        "complete" => "completed"
    ];

    if ($appointmentId <= 0 || (!isset($allowedActions[$action]) && $action !== 'reschedule')) {
        $message = "Invalid appointment action.";
        $messageType = "error";
    } elseif (!verifyCsrfToken()) {
        $message = "Your session expired. Please refresh and try again.";
        $messageType = "error";
    } elseif ($action === "reject" && $reason === "") {
        $message = "Please enter a reason for rejection.";
        $messageType = "error";
    } else {
        try {
            $pdo->beginTransaction();

            $stmt = $pdo->prepare(
                "SELECT id, patient_id, doctor_id, appointment_date, appointment_time, status
                 FROM appointments
                 WHERE id = ?
                 FOR UPDATE"
            );
            $stmt->execute([$appointmentId]);
            $appointment = $stmt->fetch();

            if (!$appointment) {
                throw new Exception("Appointment not found.");
            }

            $oldStatus = $appointment["status"];

            if ($action === 'reschedule') {
                if (!in_array($oldStatus, ['pending', 'approved'], true)) {
                    throw new Exception('Only active appointments can be rescheduled.');
                }
                $newDate = trim($_POST['new_date'] ?? '');
                $newTime = trim($_POST['new_time'] ?? '');
                if ($newDate === $appointment['appointment_date']
                    && substr($appointment['appointment_time'], 0, 5) === $newTime) {
                    throw new Exception('Choose a different date or time for the reschedule.');
                }
                $selected = availableAppointmentSlots($pdo, (int)$appointment['doctor_id'], $newDate, $appointmentId);
                if (!in_array($newTime . ':00', $selected, true) && !in_array($newTime, $selected, true)) {
                    throw new Exception('That time is unavailable. Choose an open slot during the doctor’s schedule.');
                }
                $update = $pdo->prepare('UPDATE appointments SET appointment_date = ?, appointment_time = ? WHERE id = ?');
                $update->execute([$newDate, $newTime, $appointmentId]);
                notifyUser($pdo, (int)$appointment['patient_id'], 'Your appointment has been rescheduled to ' . date('d M Y', strtotime($newDate)) . ' at ' . date('g:i A', strtotime($newTime)) . '.');
                $pdo->commit();
                $message = 'Appointment rescheduled and patient notified.';
            } else {

            $newStatus = $allowedActions[$action];
            $validTransition = false;

            if ($action === "approve" && $oldStatus === "pending") {
                $validTransition = true;
            }

            if ($action === "reject" && $oldStatus === "pending") {
                $validTransition = true;
            }

            if ($action === "complete" && $oldStatus === "approved") {
                $validTransition = true;
            }

            if (!$validTransition) {
                throw new Exception(
                    "This appointment cannot be changed from its current status."
                );
            }

            if ($action === "reject") {
                $stmt = $pdo->prepare(
                    "UPDATE appointments
                     SET status = 'rejected', rejection_reason = ?
                     WHERE id = ?"
                );
                $stmt->execute([$reason, $appointmentId]);

                $notification = "Your appointment has been rejected. Reason: " . $reason;

            } else {
                $stmt = $pdo->prepare(
                    "UPDATE appointments
                     SET status = ?
                     WHERE id = ?"
                );
                $stmt->execute([$newStatus, $appointmentId]);

                if ($action === "approve") {
                    $notification = "Your appointment has been approved.";
                } else {
                    $notification = "Your appointment has been marked as completed.";
                }
            }

            notifyUser(
                $pdo,
                (int)$appointment["patient_id"],
                $notification
            );

            $pdo->commit();

            $message = "Appointment status updated successfully.";
            }

        } catch (Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }

            $message = $e instanceof PDOException
                ? "Unable to update the appointment. Please check whether the selected time is still available."
                : $e->getMessage();

            $messageType = "error";
        }
    }
}

// Load filter options and matching appointments.
$doctors = $pdo->query("SELECT id, doctor_name FROM doctors ORDER BY doctor_name")->fetchAll();
$where = [];
$params = [];
if (!empty($_GET['date'])) {
    $where[] = 'a.appointment_date = ?';
    $params[] = $_GET['date'];
}
if (!empty($_GET['doctor_id'])) {
    $where[] = 'a.doctor_id = ?';
    $params[] = (int)$_GET['doctor_id'];
}
if (in_array($_GET['status'] ?? '', ['pending', 'approved', 'rejected', 'completed', 'cancelled'], true)) {
    $where[] = 'a.status = ?';
    $params[] = $_GET['status'];
}
$sql = "SELECT
        a.*,
        u.name AS patient_name,
        u.phone AS patient_phone,
        d.doctor_name,
        dep.department_name
     FROM appointments a
     JOIN users u ON a.patient_id = u.id
     JOIN doctors d ON a.doctor_id = d.id
     LEFT JOIN departments dep ON d.department_id = dep.id";
if ($where) {
    $sql .= ' WHERE ' . implode(' AND ', $where);
}
$sql .= ' ORDER BY a.appointment_date DESC, a.appointment_time DESC';
$stmt = $pdo->prepare($sql);
$stmt->execute($params);

$appointments = $stmt->fetchAll();

function appointmentBadge(string $status): string {
    return match ($status) {
        "approved" => "admin-badge-success",
        "rejected", "cancelled" => "admin-badge-danger",
        "completed" => "admin-badge-info",
        default => "admin-badge-warning"
    };
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Appointment Management | Clinic Admin</title>

    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/admin.css">
    <link rel="stylesheet" href="../assets/css/premium.css">
</head>
<body class="admin-page">

<div class="admin-container">

    <div class="admin-heading">
        <div>
            <h1>Appointment Management</h1>
            <p>Review and manage patient appointment requests.</p>
        </div>

        <a href="dashboard.php" class="admin-btn admin-btn-secondary">
            Back to Dashboard
        </a>
    </div>

    <nav class="admin-nav">
        <a href="dashboard.php">Dashboard</a>
        <a href="departments.php">Departments</a>
        <a href="doctors.php">Doctors</a>
        <a href="schedules.php">Schedules</a>
        <a href="days_off.php">Days Off</a>
        <a href="appointments.php">Appointments</a>
        <a href="patients.php">Patients</a>
        <a href="visit_notes.php">Visit Notes</a>
        <a href="../auth/logout.php">Logout</a>
    </nav>

    <?php if ($message): ?>
        <div class="admin-alert">
            <?= htmlspecialchars($message) ?>
        </div>
    <?php endif; ?>

    <section class="admin-card">
        <h2>All Appointments</h2>

        <form method="GET" class="admin-filters" style="display:flex;gap:12px;flex-wrap:wrap;align-items:end;margin:16px 0 22px">
            <label>Date<br><input type="date" name="date" value="<?= e($_GET['date'] ?? '') ?>"></label>
            <label>Doctor<br><select name="doctor_id"><option value="">All doctors</option>
                <?php foreach ($doctors as $doctor): ?>
                    <option value="<?= (int)$doctor['id'] ?>" <?= (string)($_GET['doctor_id'] ?? '') === (string)$doctor['id'] ? 'selected' : '' ?>><?= e($doctor['doctor_name']) ?></option>
                <?php endforeach; ?>
            </select></label>
            <label>Status<br><select name="status"><option value="">All statuses</option>
                <?php foreach (['pending', 'approved', 'rejected', 'completed', 'cancelled'] as $filterStatus): ?>
                    <option value="<?= e($filterStatus) ?>" <?= ($_GET['status'] ?? '') === $filterStatus ? 'selected' : '' ?>><?= e(ucfirst($filterStatus)) ?></option>
                <?php endforeach; ?>
            </select></label>
            <button class="admin-btn admin-btn-primary" type="submit">Filter</button>
            <a class="admin-btn admin-btn-secondary" href="appointments.php">Clear</a>
        </form>

        <div class="admin-table-wrap">
            <table class="admin-table">
                <thead>
                    <tr>
                        <th>No.</th>
                        <th>Patient</th>
                        <th>Doctor</th>
                        <th>Department</th>
                        <th>Date</th>
                        <th>Time</th>
                        <th>Status</th>
                        <th>Rejection Reason</th>
                        <th>Actions</th>
                    </tr>
                </thead>

                <tbody>
                <?php if (!$appointments): ?>
                    <tr>
                        <td colspan="9">No appointments found.</td>
                    </tr>
                <?php else: ?>

                    <?php foreach ($appointments as $index => $appointment): ?>
                        <tr>
                            <td><?= $index + 1 ?></td>

                            <td>
                                <?= htmlspecialchars($appointment["patient_name"]) ?>
                                <br>
                                <small><?= htmlspecialchars($appointment["patient_phone"] ?? "") ?></small>
                            </td>

                            <td><?= htmlspecialchars($appointment["doctor_name"]) ?></td>

                            <td><?= htmlspecialchars($appointment["department_name"] ?? "—") ?></td>

                            <td>
                                <?= date("d M Y", strtotime($appointment["appointment_date"])) ?>
                            </td>

                            <td>
                                <?= date("g:i A", strtotime($appointment["appointment_time"])) ?>
                            </td>

                            <td>
                                <span class="admin-badge <?= appointmentBadge($appointment["status"]) ?>">
                                    <?= htmlspecialchars(ucfirst($appointment["status"])) ?>
                                </span>
                            </td>

                            <td>
                                <?= htmlspecialchars($appointment["rejection_reason"] ?? "—") ?>
                            </td>

                            <td>
                                <div class="admin-actions">

                                    <?php if ($appointment["status"] === "pending"): ?>

                                        <form method="POST">
                                            <input type="hidden" name="appointment_id"
                                                   value="<?= (int)$appointment["id"] ?>">
                                            <input type="hidden" name="csrf_token" value="<?= e(csrfToken()) ?>">
                                            <input type="hidden" name="action"
                                                   value="approve">

                                            <button type="submit"
                                                    class="admin-btn admin-btn-success">
                                                Approve
                                            </button>
                                        </form>

                                        <form method="POST"
                                              onsubmit="return confirm('Reject this appointment?');">

                                            <input type="hidden" name="appointment_id"
                                                   value="<?= (int)$appointment["id"] ?>">
                                            <input type="hidden" name="csrf_token" value="<?= e(csrfToken()) ?>">
                                            <input type="hidden" name="action"
                                                   value="reject">

                                            <input type="text"
                                                   name="rejection_reason"
                                                   placeholder="Rejection reason"
                                                   required>

                                            <button type="submit"
                                                    class="admin-btn admin-btn-danger">
                                                Reject
                                            </button>
                                        </form>

                                    <?php elseif ($appointment["status"] === "approved"): ?>

                                        <form method="POST"
                                              onsubmit="return confirm('Mark this appointment as completed?');">

                                            <input type="hidden" name="appointment_id"
                                                   value="<?= (int)$appointment["id"] ?>">
                                            <input type="hidden" name="csrf_token" value="<?= e(csrfToken()) ?>">
                                            <input type="hidden" name="action"
                                                   value="complete">

                                            <button type="submit"
                                                    class="admin-btn admin-btn-primary">
                                                Complete
                                            </button>
                                        </form>

                                    <?php endif; ?>

                                    <?php if (in_array($appointment["status"], ["pending", "approved"], true)): ?>
                                        <form method="POST" class="reschedule-form" style="display:grid;gap:6px;min-width:145px">
                                            <input type="hidden" name="appointment_id" value="<?= (int)$appointment["id"] ?>">
                                            <input type="hidden" name="action" value="reschedule">
                                            <input type="hidden" name="csrf_token" value="<?= e(csrfToken()) ?>">
                                            <label><small>New date</small><input type="date" name="new_date" min="<?= date('Y-m-d') ?>" required></label>
                                            <label><small>New time</small><input type="time" name="new_time" step="60" required></label>
                                            <button type="submit" class="admin-btn admin-btn-secondary">Reschedule</button>
                                        </form>
                                    <?php else: ?>
                                        <span>—</span>
                                    <?php endif; ?>

                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>

                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </section>

</div>
    <script defer src="../assets/js/script.js"></script>
</body>
</html>
