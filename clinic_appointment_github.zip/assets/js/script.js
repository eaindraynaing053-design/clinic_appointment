/* CarePoint Clinic progressive enhancements. No framework or external library required. */
(() => {
    'use strict';

    const addPasswordVisibility = () => {
        document.querySelectorAll('input[type="password"]:not([data-cp-toggle])').forEach((input) => {
            input.dataset.cpToggle = 'true';

            const wrapper = document.createElement('span');
            wrapper.className = 'cp-password-control';
            input.parentNode.insertBefore(wrapper, input);
            wrapper.appendChild(input);

            const toggle = document.createElement('button');
            toggle.type = 'button';
            toggle.className = 'cp-password-toggle';
            toggle.textContent = 'Show';
            toggle.setAttribute('aria-label', 'Show password');
            toggle.setAttribute('aria-pressed', 'false');
            wrapper.appendChild(toggle);

            toggle.addEventListener('click', () => {
                const reveal = input.type === 'password';
                input.type = reveal ? 'text' : 'password';
                toggle.textContent = reveal ? 'Hide' : 'Show';
                toggle.setAttribute('aria-label', reveal ? 'Hide password' : 'Show password');
                toggle.setAttribute('aria-pressed', String(reveal));
                input.focus({ preventScroll: true });
            });
        });
    };

    const setupAppointmentSlots = () => {
        const form = document.querySelector('.booking-card form[method="post" i]');
        if (!form) return;

        const slots = [...form.querySelectorAll('input[name="appointment_time"]')];
        const submit = form.querySelector('button[type="submit"]');
        if (!slots.length || !submit) return;

        const idleLabel = submit.textContent.trim() || 'Confirm Appointment';
        const updateState = () => {
            const selected = slots.some((slot) => slot.checked);
            submit.disabled = !selected;
            submit.textContent = selected ? idleLabel : 'Select a time to continue';
            submit.setAttribute('aria-disabled', String(!selected));
            form.classList.toggle('has-selected-slot', selected);
        };

        slots.forEach((slot) => slot.addEventListener('change', updateState));
        updateState();
    };

    const setupCharacterCounts = () => {
        document.querySelectorAll('textarea[maxlength]').forEach((field) => {
            const maximum = Number(field.getAttribute('maxlength'));
            if (!maximum || field.dataset.cpCount === 'true') return;

            field.dataset.cpCount = 'true';
            const counter = document.createElement('small');
            counter.className = 'cp-char-count';
            counter.setAttribute('aria-live', 'polite');
            field.insertAdjacentElement('afterend', counter);

            const update = () => {
                const remaining = Math.max(0, maximum - field.value.length);
                counter.textContent = `${remaining} characters remaining`;
            };
            field.addEventListener('input', update);
            update();
        });
    };

    const setupSubmitProtection = () => {
        document.querySelectorAll('form[method="post" i]:not([onsubmit])').forEach((form) => {
            form.addEventListener('submit', (event) => {
                if (event.defaultPrevented) return;
                if (form.dataset.cpSubmitting === 'true') {
                    event.preventDefault();
                    return;
                }

                form.dataset.cpSubmitting = 'true';
                form.querySelectorAll('button[type="submit"], input[type="submit"]').forEach((button) => {
                    if (button.disabled) return;
                    button.dataset.cpOriginalLabel = button.tagName === 'INPUT' ? button.value : button.textContent;
                    button.disabled = true;
                    button.classList.add('is-loading');
                    if (button.tagName === 'INPUT') button.value = 'Please wait…';
                    else button.textContent = 'Please wait…';
                });
            });
        });
    };

    const restoreSubmitButtons = () => {
        // Browsers may restore a page from back-forward cache with buttons still disabled.
        document.querySelectorAll('form[data-cp-submitting="true"]').forEach((form) => {
            form.dataset.cpSubmitting = 'false';
            form.querySelectorAll('button.is-loading, input.is-loading').forEach((button) => {
                button.disabled = false;
                button.classList.remove('is-loading');
                const label = button.dataset.cpOriginalLabel;
                if (label !== undefined) {
                    if (button.tagName === 'INPUT') button.value = label;
                    else button.textContent = label;
                    delete button.dataset.cpOriginalLabel;
                }
            });
        });
        setupAppointmentSlots();
    };

    const injectFallbackStyles = () => {
        if (document.getElementById('cp-js-styles')) return;
        const style = document.createElement('style');
        style.id = 'cp-js-styles';
        style.textContent = `
            .cp-password-control{display:block;position:relative;width:100%}
            .cp-password-control input{width:100%;padding-right:68px!important}
            .cp-password-toggle{position:absolute;right:8px;top:50%;transform:translateY(-50%);border:0;background:transparent;color:#087f78;font:600 12px Inter,Arial,sans-serif;padding:7px 9px;cursor:pointer}
            .cp-password-toggle:focus-visible{outline:2px solid #11998e;outline-offset:2px;border-radius:6px}
            .cp-char-count{display:block;text-align:right;color:#718096;font-size:12px;margin-top:5px}
            .booking-submit:disabled{opacity:.58;cursor:not-allowed;transform:none!important;box-shadow:none!important}
            .is-loading{opacity:.72;cursor:wait}
        `;
        document.head.appendChild(style);
    };

    const init = () => {
        injectFallbackStyles();
        addPasswordVisibility();
        setupAppointmentSlots();
        setupCharacterCounts();
        setupSubmitProtection();
        window.addEventListener('pageshow', restoreSubmitButtons);
    };

    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init, { once: true });
    else init();
})();
