
<?php
// Local XAMPP defaults are convenient for development. A local .env file or
// DB_* environment variables can override them; never commit real credentials.
$localEnv = [];
$envPath = dirname(__DIR__) . '/.env';
if (is_file($envPath)) {
    $parsed = parse_ini_file($envPath, false, INI_SCANNER_RAW);
    if (is_array($parsed)) {
        $localEnv = $parsed;
    }
}
$readSetting = static function (string $key, string $default) use ($localEnv): string {
    $value = getenv($key);
    if ($value !== false) {
        return $value;
    }
    return isset($localEnv[$key]) ? (string)$localEnv[$key] : $default;
};

$host = $readSetting('DB_HOST', '127.0.0.1');
$dbname = $readSetting('DB_NAME', 'clinic_db');
$username = $readSetting('DB_USER', 'root');
$password = $readSetting('DB_PASSWORD', '');

try {
    $pdo = new PDO(
        "mysql:host=$host;dbname=$dbname;charset=utf8mb4",
        $username,
        $password
    );

    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    die("Database connection failed. Please check your database settings.");
}
