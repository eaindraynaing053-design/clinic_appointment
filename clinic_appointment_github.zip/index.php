
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>CarePoint Clinic | Your Health, Our Priority</title>

    <link rel="stylesheet" href="assets/css/style.css">

    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/premium.css">
</head>

<body>

<!-- NAVIGATION -->
<header class="navbar">
    <a href="index.php" class="logo">
        Care<span>Point</span>
    </a>

    <nav>
        <a href="index.php">Home</a>
        <a href="#services">Services</a>
        <a href="#about">About Us</a>
        <a href="#contact">Contact</a>
    </nav>

    <div class="nav-buttons">
        <a href="auth/login.php" class="login-link">Login</a>
        <a href="auth/register.php" class="register-btn">Get Started</a>
    </div>
</header>


<!-- HERO SECTION -->
<section class="hero">

    <div class="hero-content">

        <span class="tagline">WELCOME TO CAREPOINT CLINIC</span>

        <h1>
            Better Healthcare,
            <span>Better Life.</span>
        </h1>

        <p>
            Your health deserves the best care. Connect with experienced
            doctors, explore medical services, and book your appointments
            easily through CarePoint Clinic.
        </p>

        <div class="hero-buttons">
            <a href="auth/register.php" class="primary-btn">
                Book an Appointment
            </a>

            <a href="#about" class="secondary-btn">
                Learn More
            </a>
        </div>

        <div class="features">
            <div>
                <strong>Expert Doctors</strong>
                <small>Professional medical care</small>
            </div>

            <div>
                <strong>Easy Booking</strong>
                <small>Simple online appointments</small>
            </div>

            <div>
                <strong>Patient First</strong>
                <small>Your health matters</small>
            </div>
        </div>

    </div>

    <div class="hero-image">
        <img
            src="https://images.unsplash.com/photo-1559839734-2b71ea197ec2?auto=format&fit=crop&w=900&q=85"
            alt="Professional female doctor"
        >
    </div>

</section>


<!-- SERVICES SECTION -->
<section class="services" id="services">

    <span class="tagline">OUR MEDICAL SERVICES</span>

    <h2>Healthcare Services for Everyone</h2>

    <p class="section-description">
        We provide access to different medical departments
        to support your health and wellbeing.
    </p>

    <div class="service-cards">

        <div class="service-card">
            <div class="service-icon">✚</div>
            <h3>General Medicine</h3>
            <p>
                General health consultations, medical checkups,
                and treatment for common illnesses.
            </p>
        </div>

        <div class="service-card">
            <div class="service-icon">☻</div>
            <h3>Dental Care</h3>
            <p>
                Professional dental consultations and support
                for maintaining healthy teeth.
            </p>
        </div>

        <div class="service-card">
            <div class="service-icon">◉</div>
            <h3>Eye Care</h3>
            <p>
                Eye examinations, vision consultations,
                and professional eye care services.
            </p>
        </div>

        <div class="service-card">
            <div class="service-icon">♡</div>
            <h3>Cardiology</h3>
            <p>
                Heart health consultations and cardiovascular
                care from experienced specialists.
            </p>
        </div>

    </div>

</section>


<!-- ABOUT SECTION -->
<section class="about-section" id="about">

    <div class="about-image">
        <img
            src="https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?auto=format&fit=crop&w=900&q=85"
            alt="Doctor consulting a patient"
        >
    </div>

    <div class="about-content">

        <span class="tagline">ABOUT CAREPOINT</span>

        <h2>Healthcare Made Simple and Accessible</h2>

        <p>
            CarePoint Clinic is designed to make healthcare
            appointment management easier for both patients
            and clinic administrators.
        </p>

        <p>
            Patients can explore doctors, view available
            services, request appointments, and keep track
            of their appointment status in one convenient place.
        </p>

        <a href="auth/register.php" class="primary-btn">
            Join CarePoint
        </a>

    </div>

</section>


<!-- WHY CHOOSE US -->
<section class="why-section">

    <span class="tagline">WHY CHOOSE US</span>

    <h2>Care That Puts You First</h2>

    <div class="why-cards">

        <div class="why-card">
            <h3>01. Easy Appointment Booking</h3>
            <p>
                Request appointments online without unnecessary
                waiting or complicated processes.
            </p>
        </div>

        <div class="why-card">
            <h3>02. Experienced Doctors</h3>
            <p>
                Find doctors from different medical departments
                based on your healthcare needs.
            </p>
        </div>

        <div class="why-card">
            <h3>03. Organized Patient Records</h3>
            <p>
                Keep track of appointment history and
                consultation information.
            </p>
        </div>

    </div>

</section>


<!-- CALL TO ACTION -->
<section class="cta-section">

    <h2>Your Health Journey Starts Here</h2>

    <p>
        Take the first step towards better healthcare.
        Register today and book your appointment with CarePoint.
    </p>

    <a href="auth/register.php" class="cta-btn">
        Create Your Account
    </a>

</section>


<!-- FOOTER -->
<footer id="contact">

    <div class="footer-content">

        <div>
            <h2>Care<span>Point</span></h2>
            <p>
                Your health, our priority.
                Making healthcare appointments easier and more accessible.
            </p>
        </div>

        <div>
            <h3>Quick Links</h3>
            <a href="index.php">Home</a>
            <a href="#services">Services</a>
            <a href="#about">About Us</a>
        </div>

        <div>
            <h3>Account</h3>
            <a href="auth/login.php">Login</a>
            <a href="auth/register.php">Register</a>
        </div>

    </div>

    <div class="footer-bottom">
        <p>&copy; 2026 CarePoint Clinic. All Rights Reserved.</p>
    </div>

</footer>

    <script defer src="assets/js/script.js"></script>
</body>
</html>
