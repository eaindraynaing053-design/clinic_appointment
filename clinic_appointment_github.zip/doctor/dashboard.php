<?php
require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../config/database.php';
requireRole('doctor');

$doctorQuery = $pdo->prepare('SELECT id, doctor_name FROM doctors WHERE user_id = ? LIMIT 1');
$doctorQuery->execute([(int)$_SESSION['user_id']]);
$doctor = $doctorQuery->fetch();
if (!$doctor) {
    http_response_code(403);
    exit('This doctor account is not linked to a doctor profile yet. Ask an administrator to link it.');
}

$message = '';
$messageType = 'success';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $appointmentId = (int)($_POST['appointment_id'] ?? 0);
    $visitNote = trim($_POST['visit_note'] ?? '');
    $prescription = trim($_POST['prescription'] ?? '');
    if (!verifyCsrfToken()) {
        $message = 'Your session expired. Please refresh and try again.';
        $messageType = 'error';
    } elseif ($appointmentId <= 0 || $visitNote === '') {
        $message = 'Choose a completed appointment and enter a visit note.';
        $messageType = 'error';
    } else {
        try {
            $pdo->beginTransaction();
            $appointmentQuery = $pdo->prepare("SELECT patient_id FROM appointments WHERE id = ? AND doctor_id = ? AND status = 'completed' FOR UPDATE");
            $appointmentQuery->execute([$appointmentId, $doctor['id']]);
            $appointment = $appointmentQuery->fetch();
            if (!$appointment) {
                throw new RuntimeException('Only your completed appointments can receive a note.');
            }
            $existing = $pdo->prepare('SELECT 1 FROM visit_notes WHERE appointment_id = ? LIMIT 1');
            $existing->execute([$appointmentId]);
            if ($existing->fetchColumn()) {
                throw new RuntimeException('A visit note already exists for that appointment.');
            }
            $insert = $pdo->prepare('INSERT INTO visit_notes (appointment_id, doctor_id, notes, prescription) VALUES (?, ?, ?, ?)');
            $insert->execute([$appointmentId, $doctor['id'], $visitNote, $prescription]);
            notifyUser($pdo, (int)$appointment['patient_id'], 'Your completed visit record is ready in Medical History.');
            $pdo->commit();
            $message = 'Visit note saved and the patient was notified.';
        } catch (Throwable $exception) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            $message = $exception instanceof PDOException ? 'Could not save the visit note. Please try again.' : $exception->getMessage();
            $messageType = 'error';
        }
    }
}

$completedWithoutNotes = $pdo->prepare("SELECT a.id, a.appointment_date, a.appointment_time, u.name AS patient_name FROM appointments a JOIN users u ON a.patient_id = u.id WHERE a.doctor_id = ? AND a.status = 'completed' AND a.id NOT IN (SELECT appointment_id FROM visit_notes) ORDER BY a.appointment_date DESC, a.appointment_time DESC");
$completedWithoutNotes->execute([$doctor['id']]);
$appointmentsToDocument = $completedWithoutNotes->fetchAll();

$appointmentsQuery = $pdo->prepare('SELECT a.*, u.name AS patient_name, vn.notes AS visit_note, vn.prescription FROM appointments a JOIN users u ON a.patient_id = u.id LEFT JOIN visit_notes vn ON vn.appointment_id = a.id WHERE a.doctor_id = ? ORDER BY a.appointment_date DESC, a.appointment_time DESC');
$appointmentsQuery->execute([$doctor['id']]);
$appointments = $appointmentsQuery->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Doctor Dashboard | MediCare Clinic</title>
    <link rel="stylesheet" href="<?= BASE_URL ?>assets/css/style.css">
    <link rel="stylesheet" href="<?= BASE_URL ?>assets/css/admin.css">
    <link rel="stylesheet" href="<?= BASE_URL ?>assets/css/premium.css">
</head>
<body class="admin-page">
<div class="admin-container">
    <div class="admin-heading">
        <div><h1><?= e(preg_match('/^Dr\.?\s/i', $doctor['doctor_name']) ? $doctor['doctor_name'] : 'Dr. ' . $doctor['doctor_name']) ?></h1><p>Your appointments and completed visit notes.</p></div>
        <a href="<?= BASE_URL ?>auth/logout.php" class="admin-btn admin-btn-secondary">Log out</a>
    </div>

    <?php if ($message): ?><div class="admin-alert <?= $messageType === 'error' ? 'error' : 'success' ?>"><?= e($message) ?></div><?php endif; ?>

    <section class="admin-card">
        <h2>Write a visit note</h2>
        <?php if ($appointmentsToDocument): ?>
            <form method="POST" style="display:grid;gap:14px;max-width:760px">
                <input type="hidden" name="csrf_token" value="<?= e(csrfToken()) ?>">
                <label>Completed appointment
                    <select name="appointment_id" required>
                        <option value="">Choose a patient visit</option>
                        <?php foreach ($appointmentsToDocument as $visit): ?>
                            <option value="<?= (int)$visit['id'] ?>"><?= e($visit['patient_name']) ?> · <?= date('d M Y', strtotime($visit['appointment_date'])) ?> <?= date('g:i A', strtotime($visit['appointment_time'])) ?></option>
                        <?php endforeach; ?>
                    </select>
                </label>
                <label>Visit note<textarea name="visit_note" rows="4" maxlength="5000" required></textarea></label>
                <label>Prescription or care instructions (optional)<textarea name="prescription" rows="3" maxlength="5000"></textarea></label>
                <button type="submit" class="admin-btn admin-btn-primary">Save Visit Note</button>
            </form>
        <?php else: ?>
            <p>No completed visits are waiting for a note.</p>
        <?php endif; ?>
    </section>

    <section class="admin-card">
        <h2>Your appointments</h2>
        <div class="admin-table-wrap"><table class="admin-table">
            <thead><tr><th>Patient</th><th>Date</th><th>Time</th><th>Status</th><th>Visit Note</th><th>Prescription</th></tr></thead>
            <tbody>
            <?php if ($appointments): foreach ($appointments as $appointment): ?>
                <tr>
                    <td><?= e($appointment['patient_name']) ?></td>
                    <td><?= date('d M Y', strtotime($appointment['appointment_date'])) ?></td>
                    <td><?= date('g:i A', strtotime($appointment['appointment_time'])) ?></td>
                    <td><?= e(ucfirst($appointment['status'])) ?></td>
                    <td><?= nl2br(e($appointment['visit_note'] ?? '—')) ?></td>
                    <td><?= $appointment['status'] === 'completed' ? nl2br(e($appointment['prescription'] ?: '—')) : '—' ?></td>
                </tr>
            <?php endforeach; else: ?>
                <tr><td colspan="6" class="admin-empty">No appointments assigned yet.</td></tr>
            <?php endif; ?>
            </tbody>
        </table></div>
    </section>
</div>
    <script defer src="<?= BASE_URL ?>assets/js/script.js"></script>
</body>
</html>
