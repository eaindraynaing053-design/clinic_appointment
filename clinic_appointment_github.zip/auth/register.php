<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

$error = '';
$name = trim($_POST['full_name'] ?? '');
$email = trim($_POST['email'] ?? '');
$phone = trim($_POST['phone'] ?? '');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $password = $_POST['password'] ?? '';
    if (!verifyCsrfToken()) {
        $error = 'Your session expired. Please refresh and try again.';
    } elseif ($name === '' || mb_strlen($name) > 100 || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Enter a valid name and email address.';
    } elseif (strlen($password) < 8) {
        $error = 'Choose a password with at least 8 characters.';
    } else {
        $check = $pdo->prepare('SELECT id FROM users WHERE email = ? LIMIT 1');
        $check->execute([$email]);
        if ($check->fetch()) {
            $error = 'That email address already has an account. Please sign in.';
        } else {
            try {
                $insert = $pdo->prepare("INSERT INTO users (name, email, password, phone, role) VALUES (?, ?, ?, ?, 'patient')");
                $insert->execute([$name, $email, password_hash($password, PASSWORD_DEFAULT), $phone !== '' ? $phone : null]);
                setFlash('success', 'Your patient account is ready. Sign in to book an appointment.');
                redirect('auth/login.php');
            } catch (PDOException $exception) {
                $error = 'We could not create the account. Please check the details and try again.';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Patient Account | MediCare Clinic</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/premium.css">
</head>
<body>
<main class="auth-page">
    <section class="auth-card">
        <a href="../index.php" class="auth-logo"><span>✚</span> MediCare Clinic</a>
        <h1>Create your account</h1>
        <p class="auth-subtitle">A few details are all you need to book your first visit.</p>
        <?php if ($error): ?><div class="auth-error"><?= e($error) ?></div><?php endif; ?>
        <form method="POST" action="">
            <input type="hidden" name="csrf_token" value="<?= e(csrfToken()) ?>">
            <div class="form-group">
                <label for="full_name">Full name</label>
                <input id="full_name" type="text" name="full_name" value="<?= e($name) ?>" maxlength="100" autocomplete="name" required>
            </div>
            <div class="form-group">
                <label for="email">Email address</label>
                <input id="email" type="email" name="email" value="<?= e($email) ?>" maxlength="100" autocomplete="email" required>
            </div>
            <div class="form-group">
                <label for="phone">Phone number <span>(optional)</span></label>
                <input id="phone" type="tel" name="phone" value="<?= e($phone) ?>" maxlength="20" autocomplete="tel">
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input id="password" type="password" name="password" minlength="8" autocomplete="new-password" required>
                <small>Use at least 8 characters.</small>
            </div>
            <button type="submit" class="btn-primary auth-submit">Create Account →</button>
        </form>
        <p class="auth-switch">Already registered? <a href="login.php">Sign in</a></p>
        <a href="../index.php" class="back-home">← Back to Homepage</a>
    </section>
</main>
    <script defer src="../assets/js/script.js"></script>
</body>
</html>
