
<?php
session_start();

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';

// Already logged in? Go to dashboard.
if (isLoggedIn()) {
    redirect(dashboardPath(currentRole()));
}

$error = '';
$flash = getFlash();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if (!verifyCsrfToken()) {
        $error = 'Your session expired. Please refresh and try again.';
    } else {

        $email = trim($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';

        if ($email === '' || $password === '') {
            $error = 'Please enter your email and password.';
        } else {

            $stmt = $pdo->prepare(
                "SELECT id, name AS full_name, email, password, role
                 FROM users
                 WHERE email = ?
                 LIMIT 1"
            );

            $stmt->execute([$email]);
            $user = $stmt->fetch();

            if ($user && password_verify($password, $user['password'])) {

                session_regenerate_id(true);

                $_SESSION['user_id'] = (int)$user['id'];
                $_SESSION['full_name'] = $user['full_name'];
                $_SESSION['email'] = $user['email'];
                $_SESSION['role'] = $user['role'];

                redirect(dashboardPath($user['role']));

            } else {
                $error = 'Invalid email or password.';
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login | MediCare Clinic</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="../assets/css/premium.css">
</head>

<body>

<div class="auth-page">

    <div class="auth-card">

        <a href="../index.php" class="auth-logo">
            <span>✚</span> MediCare Clinic
        </a>

        <h1>Welcome Back</h1>

        <p class="auth-subtitle">
            Sign in to manage your healthcare appointments.
        </p>

        <?php if ($error): ?>
            <div class="auth-error">
                <?= e($error) ?>
            </div>
        <?php endif; ?>

        <?php if ($flash): ?>
            <div class="auth-success"><?= e($flash['message']) ?></div>
        <?php endif; ?>

        <form method="POST" action="">

            <input
                type="hidden"
                name="csrf_token"
                value="<?= e(csrfToken()) ?>"
            >

            <div class="form-group">
                <label>Email Address</label>

                <input
                    type="email"
                    name="email"
                    placeholder="Enter your email"
                    value="<?= e($_POST['email'] ?? '') ?>"
                    required
                >
            </div>

            <div class="form-group">
                <label>Password</label>

                <input
                    type="password"
                    name="password"
                    placeholder="Enter your password"
                    required
                >
            </div>

            <button type="submit" class="btn-primary auth-submit">
                Sign In →
            </button>

        </form>

        <p class="auth-switch">
            Don't have an account?
            <a href="register.php">Create an account</a>
        </p>

        <a href="../index.php" class="back-home">
            ← Back to Homepage
        </a>

    </div>

</div>

    <script defer src="../assets/js/script.js"></script>
</body>
</html>
